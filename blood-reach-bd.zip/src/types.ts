export interface Division {
  id: number;
  name: string;
}

export interface District {
  id: number;
  name: string;
  division_id: number;
  division_name?: string;
}

export interface UserProfile {
  id: number;
  name: string;
  email: string;
  role: 'donor' | 'seeker' | 'hospital_admin' | 'super_admin';
  district_id?: number;
}

export interface DonorMatch {
  donor_id: number;
  name: string;
  email: string;
  blood_group: string;
  district: string;
  division: string;
  is_available: boolean;
  proximity_rank: number;
}

export interface BloodRequest {
  id: number;
  seeker_id: number;
  blood_group: string;
  units: number;
  urgency: 'Critical' | 'High' | 'Normal';
  status: 'pending' | 'fulfilled';
  district_id: number;
  created_at: string;
  seeker?: { id: number; name: string; email: string };
  district?: { id: number; name: string };
}

export interface Hospital {
  id: number;
  name: string;
  district_id: number;
  district_name?: string;
  admin_user_id?: number;
}

export interface HospitalInventory {
  id: number;
  hospital_id: number;
  blood_group: string;
  units_available: number;
}

export interface NotificationItem {
  id: number;
  recipient_id: number;
  message: string;
  is_read: boolean;
  created_at: string;
}

export interface SystemAnalytics {
  total_users: number;
  total_donors: number;
  active_donors: number;
  total_requests: number;
  pending_requests: number;
  fulfilled_requests: number;
  total_hospitals: number;
}
