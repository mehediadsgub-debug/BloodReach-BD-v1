import React, { useState, useEffect } from "react";
import { 
  Droplet, 
  MapPin, 
  User, 
  PlusCircle, 
  CheckCircle2, 
  Bell, 
  ShieldAlert, 
  List, 
  Activity, 
  LayoutDashboard, 
  LogOut, 
  Calendar, 
  Search, 
  Building2, 
  Users, 
  Power, 
  AlertTriangle,
  Menu,
  X,
  Sparkles,
  ClipboardList
} from "lucide-react";
import {
  Division,
  District,
  UserProfile,
  DonorMatch,
  BloodRequest,
  Hospital,
  HospitalInventory,
  NotificationItem,
  SystemAnalytics
} from "./types";


export default function App() {
  // Page controls
  const [currentPage, setCurrentPage] = useState<'landing' | 'login' | 'register' | 'dashboard'>('landing');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavToSection = (page: 'landing' | 'dashboard', selector?: string) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
    if (selector) {
      setTimeout(() => {
        document.getElementById(selector)?.scrollIntoView({ behavior: 'smooth' });
      }, 200);
    }
  };
  
  // Auth state
  const [token, setToken] = useState<string | null>(localStorage.getItem("token"));
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(
    localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")!) : null
  );

  // Forms
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authName, setAuthName] = useState("");
  const [authRole, setAuthRole] = useState<'donor' | 'seeker' | 'hospital_admin' | 'super_admin'>('seeker');
  const [authDistrictId, setAuthDistrictId] = useState<string>("");
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  // Location list Cache
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [districts, setDistricts] = useState<District[]>([]);

  // Public Donor Finder States
  const [finderBloodGroup, setFinderBloodGroup] = useState("O+");
  const [finderDistrictId, setFinderDistrictId] = useState("");
  const [finderResults, setFinderResults] = useState<DonorMatch[]>([]);
  const [finderSearched, setFinderSearched] = useState(false);
  const [finderLoading, setFinderLoading] = useState(false);

  // Notifications state
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  // Blood requests state (public list/dashboard list)
  const [allRequests, setAllRequests] = useState<BloodRequest[]>([]);
  const [requestFilterDistrict, setRequestFilterDistrict] = useState("");
  const [requestFilterBloodGroup, setRequestFilterBloodGroup] = useState("");

  // Create Blood request form
  const [reqBloodGroup, setReqBloodGroup] = useState("O+");
  const [reqUnits, setReqUnits] = useState(1);
  const [reqUrgency, setReqUrgency] = useState<'Critical' | 'High' | 'Normal'>('Normal');
  const [reqDistrictId, setReqDistrictId] = useState("");

  // Donor specific state
  const [donorProfile, setDonorProfile] = useState<{
    blood_group: string;
    is_available: boolean;
    last_donated: string;
  }>({ blood_group: "A+", is_available: true, last_donated: "" });

  // Hospital management state
  const [hospitalList, setHospitalList] = useState<Hospital[]>([]);
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);
  const [hospitalInventory, setHospitalInventory] = useState<HospitalInventory[]>([]);

  // Super Admin state
  const [analytics, setAnalytics] = useState<SystemAnalytics | null>(null);
  const [usersList, setUsersList] = useState<any[]>([]);

  // Load locations config
  useEffect(() => {
    fetch("/api/divisions")
      .then(res => res.json())
      .then(data => setDivisions(data))
      .catch(err => console.error("Error holding division feeds", err));

    fetch("/api/districts")
      .then(res => res.json())
      .then(data => {
        setDistricts(data);
        if (data.length > 0) {
          setFinderDistrictId(data[0].id.toString());
          setReqDistrictId(data[0].id.toString());
          setAuthDistrictId(data[0].id.toString());
        }
      })
      .catch(err => console.error("Error holding district feeds", err));
  }, []);

  // Sync notification center and roles components load
  useEffect(() => {
    if (token) {
      fetchNotifications();
      fetchRequests();
      if (currentUser?.role === 'donor') {
        fetchDonorProfile();
      } else if (currentUser?.role === 'hospital_admin') {
        fetchHospitals();
      } else if (currentUser?.role === 'super_admin') {
        fetchAdminAnalytics();
        fetchUsersList();
      }
    } else {
      // Offline/Landing stats list
      fetchRequests();
    }
  }, [token, currentUser]);

  const fetchDonorProfile = async () => {
    try {
      const res = await fetch("/api/donors?is_available_only=false", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      const myProfile = data.find((d: any) => d.user_id === currentUser?.id);
      if (myProfile) {
        setDonorProfile({
          blood_group: myProfile.blood_group,
          is_available: myProfile.is_available,
          last_donated: myProfile.last_donated || ""
        });
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchHospitals = async () => {
    try {
      const res = await fetch("/api/hospitals");
      const list: Hospital[] = await res.json();
      setHospitalList(list);
      // Auto-select if manages one
      const match = list.find(h => h.admin_user_id === currentUser?.id);
      if (match) {
        setSelectedHospital(match);
        fetchInventory(match.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchInventory = async (hId: number) => {
    try {
      const res = await fetch(`/api/inventory?hospital_id=${hId}`);
      const data = await res.json();
      setHospitalInventory(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchAdminAnalytics = async () => {
    try {
      const res = await fetch("/api/admin/analytics", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      setAnalytics(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchUsersList = async () => {
    try {
      const res = await fetch("/api/admin/users", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      setUsersList(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchNotifications = async () => {
    if (!token) return;
    try {
      const res = await fetch("/api/notifications", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data);
        setUnreadCount(data.filter((n: any) => !n.is_read).length);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const markAllNotificationsRead = async () => {
    try {
      const res = await fetch("/api/notifications/read", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({})
      });
      if (res.ok) {
        fetchNotifications();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchRequests = async () => {
    try {
      let url = "/api/requests";
      const params = [];
      if (requestFilterBloodGroup) {
        params.push(`blood_group=${encodeURIComponent(requestFilterBloodGroup)}`);
      }
      if (requestFilterDistrict) {
        params.push(`district_id=${requestFilterDistrict}`);
      }
      if (params.length > 0) {
        url += `?${params.join("&")}`;
      }
      const res = await fetch(url);
      const data = await res.json();
      setAllRequests(data);
    } catch (e) {
      console.error("Requests query error", e);
    }
  };

  // Trigger search on Requests filter change
  useEffect(() => {
    fetchRequests();
  }, [requestFilterBloodGroup, requestFilterDistrict]);

  // Auth Functions
  const handleLogin = async (e?: React.FormEvent, customUser?: { email: string, pass: string }) => {
    if (e) e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");

    const targetEmail = customUser ? customUser.email : authEmail;
    const targetPass = customUser ? customUser.pass : authPassword;

    if (!targetEmail || !targetPass) {
      setErrorMsg("Please provide your email and account password.");
      return;
    }

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: targetEmail, password: targetPass })
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || "Authentication failed");
        return;
      }

      localStorage.setItem("token", data.access_token);
      localStorage.setItem("user", JSON.stringify(data.user));
      setToken(data.access_token);
      setCurrentUser(data.user);
      setSuccessMsg("Logged in successfully!");
      
      // Navigate to dashboard
      setCurrentPage('dashboard');
      // Clear forms
      setAuthPassword("");
    } catch (err) {
      setErrorMsg("Connection to server failed.");
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");

    if (!authName || !authEmail || !authPassword || !authRole) {
      setErrorMsg("Please enter all mandatory fields.");
      return;
    }

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: authName,
          email: authEmail,
          password: authPassword,
          role: authRole,
          district_id: authDistrictId ? parseInt(authDistrictId) : undefined
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || "Registration encountered an error");
        return;
      }

      setSuccessMsg("Account successfully registered! Please login now.");
      // Auto-fill login email
      setAuthEmail(data.email);
      setAuthPassword("");
      setCurrentPage('login');
    } catch (err) {
      setErrorMsg("Server transaction failed.");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setToken(null);
    setCurrentUser(null);
    setNotifications([]);
    setUnreadCount(0);
    setCurrentPage('landing');
  };

  // Donor Search / Match
  const executeFinderMatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setFinderLoading(true);
    setFinderSearched(true);
    
    try {
      const res = await fetch(`/api/match?blood_group=${encodeURIComponent(finderBloodGroup)}&district_id=${finderDistrictId}`);
      if (res.ok) {
        const data = await res.json();
        setFinderResults(data);
      } else {
        const err = await res.json();
        setErrorMsg(err.error || "Failed finding matches");
      }
    } catch (e) {
      console.error(e);
    } finally {
      setFinderLoading(false);
    }
  };

  // Actions inside dashboards
  const toggleDonorAvailability = async () => {
    try {
      const nextState = !donorProfile.is_available;
      const res = await fetch("/api/donor/availability", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ is_available: nextState })
      });
      if (res.ok) {
        const updated = await res.json();
        setDonorProfile(prev => ({ ...prev, is_available: updated.is_available }));
        setSuccessMsg("Your availability was successfully toggled.");
        fetchNotifications();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const updateDonorProfileDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg("");
    setErrorMsg("");

    try {
      const res = await fetch("/api/donor/update", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          blood_group: donorProfile.blood_group,
          is_available: donorProfile.is_available,
          last_donated: donorProfile.last_donated || null
        })
      });

      const data = await res.json();
      if (res.ok) {
        setSuccessMsg("Donor profiling details updated successfully!");
        fetchNotifications();
      } else {
        setErrorMsg(data.error || "Failed update");
      }
    } catch (e) {
      setErrorMsg("Failed to update donor profile.");
    }
  };

  // Create blood request Action
  const createBloodRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");

    if (!reqDistrictId) {
      setErrorMsg("Seeker district must be specified for logical area routing.");
      return;
    }

    try {
      const res = await fetch("/api/requests", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          blood_group: reqBloodGroup,
          units: reqUnits,
          urgency: reqUrgency,
          district_id: parseInt(reqDistrictId)
        })
      });

      const data = await res.json();
      if (res.ok) {
        setSuccessMsg(`Urgent Request established! Alert sent in real-time to active matches.`);
        fetchRequests();
        fetchNotifications();
      } else {
        setErrorMsg(data.error || "Failed creating request");
      }
    } catch (err) {
      setErrorMsg("Network error trying to request blood.");
    }
  };

  const fulfillRequest = async (id: number) => {
    try {
      const res = await fetch(`/api/requests/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ status: "fulfilled" })
      });
      if (res.ok) {
        setSuccessMsg("Request status updated to Fulfilled successfully!");
        fetchRequests();
        fetchNotifications();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Hospital stocks modifier
  const changeHospitalStockUnits = async (bloodGroup: string, currentVal: number, modification: number) => {
    if (!selectedHospital) return;
    setErrorMsg("");
    setSuccessMsg("");

    const targetVal = Math.max(0, currentVal + modification);

    try {
      const res = await fetch("/api/inventory", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          hospital_id: selectedHospital.id,
          blood_group: bloodGroup,
          units_available: targetVal
        })
      });

      if (res.ok) {
        fetchInventory(selectedHospital.id);
        fetchNotifications();
      } else {
        const error = await res.json();
        setErrorMsg(error.error || "Stock update failed.");
      }
    } catch (e) {
      setErrorMsg("Unable to transmit stock unit modifications.");
    }
  };

  // Demo Fast Simulator logins
  const simulateRoleLogin = (roleMail: string, rolePass: string) => {
    setAuthEmail(roleMail);
    setAuthPassword(rolePass);
    handleLogin(undefined, { email: roleMail, pass: rolePass });
  };

  // Auto-clear message banners after 5 seconds
  useEffect(() => {
    if (successMsg || errorMsg) {
      const t = setTimeout(() => {
        setSuccessMsg("");
        setErrorMsg("");
      }, 7000);
      return () => clearTimeout(t);
    }
  }, [successMsg, errorMsg]);

  return (
    <div className="flex h-screen w-screen bg-slate-50 text-slate-900 overflow-hidden font-sans relative" id="main_container">
      {/* ─── DESKTOP SIDEBAR NAVIGATION ─── */}
      <aside className="w-64 bg-slate-950 text-white hidden md:flex flex-col shrink-0 border-r border-slate-800/80" id="sleek_sidebar">
        <div className="p-6 flex items-center gap-3 border-b border-slate-800/70 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center text-white shadow-md shadow-red-500/20 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-red-500/30">
            <Droplet className="w-5 h-5 fill-white/20 animate-pulse text-white" />
          </div>
          <div>
            <span className="font-extrabold tracking-tight text-base text-white block">BloodReach</span>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block -mt-1 leading-none">Bangladesh</span>
          </div>
        </div>
        
        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 px-2">Main Menu</div>
          
          <button 
            onClick={() => handleNavToSection('landing')}
            className={`w-full flex items-center gap-3 px-3 py-2.8 rounded-xl text-xs font-semibold tracking-wide transition-all duration-200 text-left cursor-pointer ${
              currentPage === 'landing' ? 'bg-gradient-to-r from-red-600/15 to-red-600/5 text-red-500 border-l-4 border-red-500 font-bold' : 'text-slate-400 hover:bg-slate-900 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 shrink-0" />
            Dashboard Overviews
          </button>
          
          <button 
            onClick={() => handleNavToSection('landing', 'open_alerts_tab')}
            className="w-full flex items-center gap-3 px-3 py-2.8 rounded-xl text-xs font-semibold tracking-wide transition-all duration-200 text-slate-400 hover:bg-slate-900 hover:text-white text-left cursor-pointer"
          >
            <Activity className="w-4 h-4 shrink-0 text-red-500/80" />
            Active Blood Requests
          </button>
          
          <button 
            onClick={() => handleNavToSection('landing', 'donor_finder_card')}
            className="w-full flex items-center gap-3 px-3 py-2.8 rounded-xl text-xs font-semibold tracking-wide transition-all duration-200 text-slate-400 hover:bg-slate-900 hover:text-white text-left cursor-pointer"
          >
            <Search className="w-4 h-4 shrink-0 text-slate-450" />
            Proximity Donors Directory
          </button>
 
           {token && (
            <button 
              onClick={() => handleNavToSection('dashboard')}
              className={`w-full flex items-center gap-3 px-3 py-2.8 rounded-xl text-xs font-semibold tracking-wide transition-all duration-200 text-left cursor-pointer ${
                currentPage === 'dashboard' ? 'bg-gradient-to-r from-red-600/15 to-red-600/5 text-red-500 border-l-4 border-red-500 font-bold' : 'text-slate-450 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <User className="w-4 h-4 shrink-0 text-emerald-550" />
              My Profile Dashboard
            </button>
          )}
 
          <div className="pt-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 px-2">System Access</div>
          
          {token ? (
            <div className="space-y-2 px-2">
              <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800/80 space-y-1">
                <div className="text-xs font-bold text-slate-200 truncate">{currentUser?.name}</div>
                <div className="text-[9px] text-red-405 font-mono capitalize tracking-wider bg-red-950/20 px-1.5 py-0.5 rounded-md inline-block border border-red-900/30">
                  {currentUser?.role.replace('_', ' ')}
                </div>
              </div>
              <button 
                onClick={handleLogout}
                className="w-full py-2 bg-slate-900 border border-slate-800 text-slate-400 hover:bg-red-950/40 hover:text-red-400 rounded-xl text-xs font-bold transition-all text-center cursor-pointer flex items-center justify-center gap-2"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign Out
              </button>
            </div>
          ) : (
            <div className="space-y-2 px-2 pt-1">
              <button 
                onClick={() => setCurrentPage('login')}
                className="w-full text-center py-2.5 bg-slate-900 text-slate-200 rounded-xl text-xs font-bold hover:bg-slate-850 border border-slate-800 transition-colors cursor-pointer"
              >
                Log In
              </button>
              <button 
                onClick={() => setCurrentPage('register')}
                className="w-full text-center py-2.5 bg-gradient-to-r from-red-600 to-rose-600 text-white rounded-xl text-xs font-bold hover:from-red-700 hover:to-rose-750 transition-all shadow-md shadow-red-900/20 cursor-pointer"
              >
                Register
              </button>
            </div>
          )}
        </nav>
 
        <div className="p-4 border-t border-slate-850 bg-slate-950 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center border border-slate-800 text-xs font-extrabold text-slate-200 shrink-0 font-mono shadow-inner shadow-black/40">
              {currentUser ? currentUser.name.slice(0, 2).toUpperCase() : 'BD'}
            </div>
            <div className="overflow-hidden">
              <div className="text-xs font-bold text-white truncate">{currentUser ? currentUser.name : 'Guest Session'}</div>
              <div className="text-[10px] text-slate-500 font-medium truncate tracking-wide">{currentUser ? currentUser.role.replace('_', ' ') : 'Proximity Network Active'}</div>
            </div>
          </div>
        </div>
      </aside>

      {/* ─── MOBILE SIDEBAR DRAWER ─── */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden" id="mobile_drawer_container">
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs focus:outline-none" onClick={() => setMobileMenuOpen(false)}></div>
          
          <div className="relative flex flex-col w-64 max-w-xs bg-slate-950 text-white h-full p-6 shadow-2xl animate-fade-in z-55 border-r border-slate-800">
            <div className="absolute top-4 right-4 animate-bounce animate-duration-1000">
              <button onClick={() => setMobileMenuOpen(false)} className="text-slate-400 hover:text-white p-2 bg-slate-900 border border-slate-800 rounded-xl cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-3 pb-6 border-b border-slate-800/80">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center text-white shadow-md shadow-red-500/20">
                <Droplet className="w-5 h-5 fill-white/20 animate-pulse text-white" />
              </div>
              <div>
                <span className="font-extrabold tracking-tight text-base text-white block">BloodReach</span>
                <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block -mt-1 leading-none">Bangladesh Hub</span>
              </div>
            </div>

            <nav className="flex-1 py-6 space-y-1 overflow-y-auto">
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 px-2">Navigation</div>
              <button 
                onClick={() => handleNavToSection('landing')}
                className={`w-full flex items-center gap-3 px-3 py-2.8 rounded-xl text-xs font-semibold tracking-wide transition-all duration-200 text-left ${
                  currentPage === 'landing' ? 'bg-gradient-to-r from-red-600/15 to-red-600/5 text-red-500 border-l-4 border-red-600' : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                }`}
              >
                <LayoutDashboard className="w-4 h-4 shrink-0" />
                Dashboard Overviews
              </button>
              
              <button 
                onClick={() => handleNavToSection('landing', 'open_alerts_tab')}
                className="w-full flex items-center gap-3 px-3 py-2.8 rounded-xl text-xs font-semibold tracking-wide transition-all duration-200 text-slate-400 hover:bg-slate-900 hover:text-white text-left"
              >
                <Activity className="w-4 h-4 shrink-0 text-red-500/80" />
                Active Requests
              </button>
              
              <button 
                onClick={() => handleNavToSection('landing', 'donor_finder_card')}
                className="w-full flex items-center gap-3 px-3 py-2.8 rounded-xl text-xs font-semibold tracking-wide transition-all duration-200 text-slate-400 hover:bg-slate-900 hover:text-white text-left"
              >
                <Search className="w-4 h-4 shrink-0" />
                Donors Directory
              </button>

              {token && (
                <button 
                  onClick={() => handleNavToSection('dashboard')}
                  className={`w-full flex items-center gap-3 px-3 py-2.8 rounded-xl text-xs font-semibold tracking-wide transition-all text-left ${
                    currentPage === 'dashboard' ? 'bg-gradient-to-r from-red-600/15 to-red-600/5 text-red-500 border-l-4 border-red-600' : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                  }`}
                >
                  <User className="w-4 h-4 shrink-0" />
                  My Profile Hub
                </button>
              )}

              <div className="pt-6 text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 px-2">Access Control</div>
              
              {token ? (
                <div className="space-y-2 px-2">
                  <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800/80 space-y-1">
                    <div className="text-xs font-bold text-slate-200 truncate">{currentUser?.name}</div>
                    <div className="text-[9px] text-red-405 font-mono capitalize tracking-wider bg-red-950/20 px-1.5 py-0.5 rounded-md inline-block border border-red-900/30">
                      {currentUser?.role.replace('_', ' ')}
                    </div>
                  </div>
                  <button 
                    onClick={handleLogout}
                    className="w-full py-2 bg-slate-900 border border-slate-800 text-slate-450 hover:bg-red-950/40 hover:text-red-400 rounded-xl text-xs font-bold transition-all text-center cursor-pointer flex items-center justify-center gap-2"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    Sign Out
                  </button>
                </div>
              ) : (
                <div className="space-y-2 px-2 pt-1">
                  <button 
                    onClick={() => { setCurrentPage('login'); setMobileMenuOpen(false); }}
                    className="w-full text-center py-2.5 bg-slate-900 border border-slate-800 text-slate-200 rounded-xl text-xs font-bold hover:bg-slate-850 transition-colors cursor-pointer"
                  >
                    Log In
                  </button>
                  <button 
                    onClick={() => { setCurrentPage('register'); setMobileMenuOpen(false); }}
                    className="w-full text-center py-2.5 bg-gradient-to-r from-red-600 to-rose-600 text-white rounded-xl text-xs font-bold hover:from-red-700 hover:to-rose-750 transition-colors shadow-md shadow-red-900/20 cursor-pointer"
                  >
                    Register
                  </button>
                </div>
              )}
            </nav>
          </div>
        </div>
      )}

      {/* ─── MAIN APP CONTENT COLUMN ─── */}
      <main className="flex-1 flex flex-col overflow-hidden h-full" id="content_column">
        {/* Header Block */}
        <header className="h-16 bg-white border-b border-slate-100 flex items-center justify-between px-6 shrink-0 z-20 shadow-xs">
          <div className="flex items-center gap-3">
            {/* Burger toggle */}
            <button 
              onClick={() => setMobileMenuOpen(true)}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-50 rounded-xl md:hidden shrink-0 cursor-pointer transition-all border border-transparent hover:border-slate-100"
            >
              <Menu className="w-5 h-5" />
            </button>
            
            <div className="flex items-center gap-2 text-xs font-semibold">
              <span className="text-slate-400 hover:text-slate-900 cursor-pointer transition-colors" onClick={() => handleNavToSection('landing')}>Home</span>
              <span className="text-slate-300">/</span>
              <span className="text-slate-800 font-extrabold capitalize tracking-wide bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-100">
                {currentPage === 'landing' ? 'Active Grid overview' : `${currentPage.replace('_', ' ')} Panel`}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Quick alert indicator if registered */}
            {token && (
              <div 
                className="relative cursor-pointer p-2 hover:bg-slate-50 rounded-xl transition-all border border-transparent hover:border-slate-120/80" 
                onClick={() => { setCurrentPage('dashboard'); markAllNotificationsRead(); }}
              >
                <Bell className="w-4.5 h-4.5 text-slate-500 hover:text-slate-800 transition-colors" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-red-600 text-[9px] text-white flex items-center justify-center rounded-full border-2 border-white font-bold animate-pulse">
                    {unreadCount}
                  </span>
                )}
              </div>
            )}

            <button 
              onClick={() => {
                if (token) {
                  setCurrentPage('dashboard');
                  setTimeout(() => {
                    document.getElementById('seeker_req_form')?.scrollIntoView({ behavior: 'smooth' });
                  }, 200);
                } else {
                  setCurrentPage('login');
                }
              }}
              className="bg-gradient-to-r from-red-650 to-rose-600 text-white px-4 py-2.2 rounded-xl text-xs font-bold hover:from-red-700 hover:to-rose-700 transition-all shadow-md shadow-red-500/10 cursor-pointer tracking-wider uppercase"
            >
              + Create Request
            </button>
          </div>
        </header>

        {/* Outer scrollable viewport wrapper */}
        <div className="flex-1 overflow-y-auto bg-slate-50/50" id="scroll_viewport">
          
          {/* Status Message Toasts */}
          {(successMsg || errorMsg) && (
            <div className="fixed bottom-6 right-6 z-50 max-w-sm w-full animate-fade-in" id="toast_container">
              {successMsg && (
                <div className="bg-slate-900 text-white border border-slate-800/80 rounded-2xl p-4.5 shadow-2xl flex items-start gap-3 transition-all">
                  <div className="p-1.5 bg-emerald-500/10 rounded-lg text-emerald-400 shrink-0">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div className="space-y-1">
                    <span className="font-extrabold text-xs text-white tracking-wide block">Success Transaction</span>
                    <span className="text-[11px] text-slate-300 font-medium leading-relaxed block">{successMsg}</span>
                  </div>
                </div>
              )}
              {errorMsg && (
                <div className="bg-slate-900 text-white border border-slate-800/80 rounded-2xl p-4.5 shadow-2xl flex items-start gap-3 transition-all">
                  <div className="p-1.5 bg-red-500/10 rounded-lg text-red-405 shrink-0">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div className="space-y-1">
                    <span className="font-extrabold text-xs text-white tracking-wide block">Alert Notice</span>
                    <span className="text-[11px] text-slate-300 font-medium leading-relaxed block">{errorMsg}</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Quick simulation controls of Bangladesh role presets */}
          {!token && (
            <div className="bg-slate-950 text-slate-300 py-4 px-6 border-b border-slate-900 shadow-xs" id="role_simulator_panel">
              <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-4 text-xs font-semibold">
                <span className="flex items-center gap-2 text-white font-extrabold uppercase tracking-widest text-[11px]">
                  <Sparkles className="w-4 h-4 text-rose-500 animate-pulse" />
                  Live Role Presets Simulation
                </span>
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <button 
                    onClick={() => simulateRoleLogin("rahim@dummy.com", "donor123")} 
                    className="bg-slate-900 hover:bg-red-950/40 text-red-405 border border-slate-800 hover:border-red-900/40 font-bold py-1.8 px-3.5 rounded-xl transition-all cursor-pointer text-xs"
                    title="A+ Active Donor, Dhaka"
                  >
                    Donor Profile (Rahim)
                  </button>
                  <button 
                    onClick={() => simulateRoleLogin("tasnim@dummy.com", "seeker123")} 
                    className="bg-slate-900 hover:bg-blue-950/40 text-blue-400 border border-slate-800 hover:border-blue-900/40 font-bold py-1.8 px-3.5 rounded-xl transition-all cursor-pointer text-xs"
                    title="Seeker Profile (Tasnim)"
                  >
                    Seeker Profile (Tasnim)
                  </button>
                  <button 
                    onClick={() => simulateRoleLogin("dmc@bloodreach.bd", "hospital123")} 
                    className="bg-slate-900 hover:bg-emerald-950/40 text-emerald-400 border border-slate-800 hover:border-emerald-900/40 font-bold py-1.8 px-3.5 rounded-xl transition-all cursor-pointer text-xs"
                    title="DMC Hospital Stock Coordinator"
                  >
                    Hospital Coordinator (DMC)
                  </button>
                  <button 
                    onClick={() => simulateRoleLogin("admin@bloodreach.bd", "admin123")} 
                    className="bg-slate-900 hover:bg-amber-950/40 text-amber-400 border border-slate-800 hover:border-amber-900/40 font-bold py-1.8 px-3.5 rounded-xl transition-all cursor-pointer text-xs"
                    title="Super Admin Overwatch"
                  >
                    Super Administrator
                  </button>
                </div>
                <span className="text-slate-500 text-[11px] font-medium block lg:inline text-center">
                  *Click any button for instant simulated authorization.
                </span>
              </div>
            </div>
          )}

          {/* Core Content Body Frame */}
          <div className="max-w-7xl mx-auto p-4 md:p-8 space-y-10">
            
            {/* ========================================================
                LANDING & SEARCH VIEW
                ======================================================== */}
            {currentPage === 'landing' && (
              <div className="space-y-12" id="landing_view">
                {/* Hero / Impact Section */}
                <section className="bg-gradient-to-br from-slate-900 via-rose-950 to-red-950 rounded-2xl p-8 md:p-12 text-white shadow-xl shadow-red-950/15 flex flex-col lg:flex-row items-center justify-between gap-8 relative overflow-hidden border border-slate-800/60" id="hero_section">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none"></div>
                  <div className="space-y-6 max-w-xl z-15">
                    <div className="inline-flex items-center gap-2 bg-red-600/15 text-red-400 border border-red-900/30 rounded-full px-3.5 py-1 text-xs font-bold font-mono tracking-wide uppercase">
                      <Sparkles className="w-3.5 h-3.5 text-red-400" />
                      Connecting Districts Across Bangladesh
                    </div>
                    <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight">
                      Seconds Save Lives. Match Blood in Proximity.
                    </h2>
                    <p className="text-slate-300 text-sm md:text-base leading-relaxed font-medium">
                      BloodReach BD bridges together blood seekers, active civilian donors, and verified hospital stock inventories on a real-time localized grid. Specify your target district, scan availability, and secure clinical lifelines immediately.
                    </p>
                    <div className="flex flex-wrap items-center gap-3.5 pt-2">
                      <button 
                        onClick={() => document.getElementById('donor_finder_card')?.scrollIntoView({ behavior: 'smooth' })} 
                        className="bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs uppercase tracking-wider px-6 py-3.5 rounded-xl transition-all shadow-lg hover:shadow-red-650/20 cursor-pointer border border-red-500/10"
                        id="hero_btn_find"
                      >
                        Find Live Donors Now
                      </button>
                      <button 
                        onClick={() => setCurrentPage('register')} 
                        className="bg-slate-900 hover:bg-slate-850 hover:text-white border border-slate-800 text-slate-300 font-bold text-xs uppercase tracking-wider px-6 py-3.5 rounded-xl transition-all cursor-pointer"
                        id="hero_btn_join"
                      >
                        Join as Active Donor
                      </button>
                    </div>
                  </div>

                  {/* Graphic stats box */}
                  <div className="w-full lg:w-80 bg-slate-950/70 backdrop-blur-md border border-slate-800/80 rounded-2xl p-6 text-white space-y-4 shrink-0 z-15" id="hero_stats">
                    <h4 className="font-bold text-xs tracking-wider uppercase text-slate-400 border-b border-slate-900 pb-2.5">Live Database Snapshot</h4>
                    <div className="grid grid-cols-2 gap-3 pt-1">
                      <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800/30">
                        <span className="block text-xl font-extrabold text-rose-505">100%</span>
                        <span className="text-[9px] uppercase font-bold text-slate-450 tracking-wider">Local Verified</span>
                      </div>
                      <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800/30">
                        <span className="block text-xl font-extrabold text-slate-200">64</span>
                        <span className="text-[9px] uppercase font-bold text-slate-450 tracking-wider">Districts</span>
                      </div>
                      <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800/30">
                        <span className="block text-xl font-extrabold text-slate-200">&lt; 3m</span>
                        <span className="text-[9px] uppercase font-bold text-slate-455 tracking-wider">Matched</span>
                      </div>
                      <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800/30">
                        <span className="block text-xl font-extrabold text-slate-200">8</span>
                        <span className="text-[9px] uppercase font-bold text-slate-450 tracking-wider">Divisions</span>
                      </div>
                    </div>
                  </div>
                </section>

                {/* Donor Finder Match Logic Card */}
                <div id="donor_finder_card" className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden scroll-mt-22">
                  <div className="border-b border-slate-100 bg-slate-50/70 p-6 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center text-red-650 shrink-0 border border-red-100 shadow-xs">
                        <Search className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-extrabold text-sm text-slate-900">Immediate Proximity Donor Finder</h3>
                        <p className="text-slate-500 text-xs mt-0.5">Ranks active blood donors across Bangladesh by home districts proximity instantly.</p>
                      </div>
                    </div>
                    <div className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200/80 text-[9px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
                      ACTIVE NODE INDEX
                    </div>
                  </div>

                  <div className="p-6">
                    <form onSubmit={executeFinderMatch} className="grid grid-cols-1 md:grid-cols-3 gap-5 inline-form" id="finder_form">
                      <div>
                        <label className="block text-xs font-bold text-slate-600 uppercase tracking-widest mb-2">Blood Group Needed</label>
                        <select 
                          value={finderBloodGroup} 
                          onChange={(e) => setFinderBloodGroup(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 rounded-xl px-3.5 py-3 focus:outline-none focus:ring-4 focus:ring-red-500/5 text-slate-800 text-sm font-semibold transition-all cursor-pointer"
                          id="finder_select_bg"
                        >
                          {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => (
                            <option key={bg} value={bg}>{bg}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-600 uppercase tracking-widest mb-2">Target District</label>
                        <select 
                          value={finderDistrictId} 
                          onChange={(e) => setFinderDistrictId(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 rounded-xl px-3.5 py-3 focus:outline-none focus:ring-4 focus:ring-red-500/5 text-slate-800 text-sm font-semibold transition-all cursor-pointer"
                          id="finder_select_dist"
                        >
                          {districts.map(d => (
                            <option key={d.id} value={d.id}>{d.name} ({d.division_name})</option>
                          ))}
                        </select>
                      </div>

                      <div className="flex items-end">
                        <button 
                          type="submit" 
                          className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-red-500/10 active:scale-[0.98]"
                          id="finder_submit"
                        >
                          {finderLoading ? "Scanning Database..." : "Search Registered Donors"}
                        </button>
                      </div>
                    </form>
                                      {/* Match Outcomes */}
                {finderSearched && (
                  <div className="mt-8 border-t border-slate-150 pt-6 animate-fade-in" id="finder_results_block">
                    <h4 className="font-extrabold text-[12px] uppercase tracking-wider text-slate-800 mb-5 pb-3 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <span className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-red-500" />
                        Proximity Search Matches ({finderResults.length} records)
                      </span>
                      <span className="text-[11px] text-red-650 bg-red-50 border border-red-100 px-3 py-1 rounded-lg font-mono normal-case">
                        Blood {finderBloodGroup} • Target District #{finderDistrictId}
                      </span>
                    </h4>

                    {finderResults.length === 0 ? (
                      <div className="bg-slate-50 border border-slate-200/60 text-slate-550 text-center py-12 rounded-2xl p-6">
                        <AlertTriangle className="w-10 h-10 text-rose-500 mx-auto mb-2" />
                        <h5 className="font-bold text-slate-900 text-sm">No Active Donors Found</h5>
                        <p className="text-xs text-slate-500 mt-1.5 max-w-sm mx-auto leading-relaxed">
                          No active donors currently match this criteria. Try expanding search options or authorize above to issue a broadcast alert.
                        </p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5" id="finder_rows">
                        {finderResults.map((match) => (
                          <div 
                            key={match.donor_id} 
                            className={`border rounded-2xl p-5 relative overflow-hidden transition-all duration-300 hover:scale-[1.01] hover:shadow-md ${
                              match.proximity_rank === 1 
                                ? 'bg-gradient-to-br from-red-50/50 to-white border-red-200 hover:border-red-400 shadow-sm' 
                                : match.proximity_rank === 2 
                                  ? 'bg-gradient-to-br from-blue-50/20 to-white border-blue-200 hover:border-blue-300' 
                                  : 'bg-white border-slate-200 hover:border-slate-300'
                            }`}
                          >
                            <div className="absolute top-0 right-0">
                              <span className={`text-[8.5px] font-extrabold uppercase tracking-widest px-3 py-1.5 rounded-bl-xl text-white inline-block ${
                                match.proximity_rank === 1 ? 'bg-gradient-to-r from-red-600 to-rose-600' : match.proximity_rank === 2 ? 'bg-gradient-to-r from-blue-600 to-indigo-605' : 'bg-slate-500'
                              }`}>
                                {match.proximity_rank === 1 ? 'Same District' : match.proximity_rank === 2 ? 'Same Division' : 'National'}
                              </span>
                            </div>

                            <div className="flex items-center gap-3.5 mb-4 mt-2">
                              <div className="w-10 h-10 rounded-xl bg-slate-950 text-white font-extrabold flex items-center justify-center text-[13px] shadow-sm">
                                {match.blood_group}
                              </div>
                              <div className="overflow-hidden">
                                <h5 className="font-extrabold text-slate-900 text-xs truncate leading-snug">{match.name}</h5>
                                <p className="text-slate-455 text-[11px] truncate">{match.email}</p>
                              </div>
                            </div>

                            <div className="space-y-2 text-xs text-slate-650 border-t border-slate-100 pt-3.5">
                              <div className="flex items-center gap-2">
                                <MapPin className="w-3.5 h-3.5 text-red-500/85 shrink-0" />
                                <span className="font-semibold text-slate-800">{match.district}, {match.division} Division</span>
                              </div>
                              <div className="flex items-center gap-2 pt-1">
                                <span className="relative flex h-2 w-2">
                                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                                </span>
                                <span className="text-emerald-705 font-bold text-[11px] tracking-wide uppercase">Active & Available</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Emergency Alerts Feed & Active Blood Requests */}
            <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6 space-y-6" id="open_alerts_tab">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                <div>
                  <h3 className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Users className="w-5 h-5 text-red-605" />
                    Open Blood Requests (Active Urgent Alerts)
                  </h3>
                  <p className="text-slate-500 text-xs mt-0.5">Critical & high-priority blood alerts sorted systematically for quick responder intervention</p>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-xs" id="table_filters">
                  <select 
                    value={requestFilterBloodGroup} 
                    onChange={(e) => setRequestFilterBloodGroup(e.target.value)}
                    className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.8 text-slate-700"
                    id="filter_bg"
                  >
                    <option value="">All Blood Groups</option>
                    {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>

                  <select 
                    value={requestFilterDistrict} 
                    onChange={(e) => setRequestFilterDistrict(e.target.value)}
                    className="bg-white border border-slate-200 rounded-xl px-3.5 py-2.2 text-slate-800 text-xs font-semibold hover:border-slate-300 transition-all cursor-pointer"
                    id="filter_dist"
                  >
                    <option value="">All Districts (All Bangladesh)</option>
                    {districts.map(d => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {allRequests.length === 0 ? (
                <div className="text-center py-14 bg-slate-50 border border-slate-200/50 rounded-2xl p-6">
                  <ClipboardList className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                  <p className="text-sm font-extrabold text-slate-800">No active blood requests found</p>
                  <p className="text-xs text-slate-500 mt-1">All citizens request grids are currently synchronized. You can create a request if needed.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="alerts_grid">
                  {allRequests.map(req => (
                    <div 
                      key={req.id} 
                      className={`border rounded-2xl p-6 flex flex-col justify-between transition-all duration-300 hover:scale-[1.01] hover:shadow-lg hover:shadow-slate-100 relative overflow-hidden ${
                        req.urgency === 'Critical' 
                          ? 'bg-gradient-to-br from-red-50/20 to-white border-red-300 shadow-sm shadow-red-100/40' 
                          : req.urgency === 'High' 
                            ? 'bg-gradient-to-br from-amber-50/10 to-white border-amber-300' 
                            : 'bg-white border-slate-150'
                      }`}
                    >
                      {req.urgency === 'Critical' && (
                        <div className="absolute top-0 right-0 bg-red-600 text-white font-extrabold text-[8.5px] uppercase tracking-widest px-4 py-1.5 rounded-bl-xl shadow-xs">
                          CRITICAL ALERT
                        </div>
                      )}

                      <div>
                        {/* Title details */}
                        <div className="flex items-center justify-between mb-4">
                          <span className={`text-[9px] uppercase font-extrabold px-3 py-1 rounded-full border tracking-wider font-mono ${
                            req.urgency === 'Critical' 
                              ? 'bg-red-50 text-red-700 border-red-200' 
                              : req.urgency === 'High' 
                                ? 'bg-amber-50 text-amber-700 border-amber-200 font-bold' 
                                : 'bg-slate-50 text-slate-600 border-slate-200'
                          }`}>
                            {req.urgency} Priority
                          </span>
                          <span className="text-slate-400 font-mono text-[10px] bg-slate-50 px-2 py-0.8 rounded-md border border-slate-100">
                            {new Date(req.created_at).toLocaleDateString()}
                          </span>
                        </div>

                        <div className="flex items-center gap-4.5 my-4">
                          <div className="w-12 h-12 rounded-xl bg-slate-950 text-white font-black flex flex-col items-center justify-center text-md leading-none shadow-sm shrink-0 border border-slate-800">
                            <span>{req.blood_group}</span>
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-900 text-xs">
                              Required: {req.units} Blood Unit{req.units > 1 ? 's' : ''}
                            </h4>
                            <p className="text-slate-500 text-[11px] mt-0.5">
                              Requested by <span className="font-semibold text-slate-700">{req.seeker?.name || "Anonymous"}</span>
                            </p>
                          </div>
                        </div>

                        <div className="space-y-2 text-slate-650 text-xs border-t border-slate-100 pt-4 mt-4">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-3.5 h-3.5 text-red-500/85 shrink-0" />
                            <span className="font-semibold text-slate-800">
                              District: {req.district?.name || "Unknown District"}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span>Post Status: <span className="font-semibold text-red-600 bg-red-50 border border-red-100 px-1.8 py-0.5 rounded text-[10px]">{req.status === 'pending' ? 'Unfulfilled (Active)' : 'Fulfilled'}</span></span>
                          </div>
                        </div>
                      </div>

                      {token && (currentUser?.role === 'super_admin' || currentUser?.role === 'hospital_admin' || req.seeker_id === currentUser?.id) && req.status === 'pending' && (
                        <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-end">
                          <button 
                            onClick={() => fulfillRequest(req.id)}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] uppercase tracking-wider font-extrabold py-2 px-3.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Mark as Fulfilled
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Informational / General workflow of platform */}
            <section className="grid grid-cols-1 md:grid-cols-3 gap-6" id="info_grid">
              <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-xs text-center space-y-3">
                <div className="w-11 h-11 bg-red-50 text-red-600 rounded-xl flex items-center justify-center mx-auto">
                  <Activity className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Real-Time Alerts</h4>
                <p className="text-slate-500 text-xs leading-relaxed">
                  Seekers post immediate alerts. Available donors matching target criteria receive match reports via their local notifications hub.
                </p>
              </div>

              <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-xs text-center space-y-3">
                <div className="w-11 h-11 bg-red-50 text-red-600 rounded-xl flex items-center justify-center mx-auto">
                  <MapPin className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Proximity Focus</h4>
                <p className="text-slate-500 text-xs leading-relaxed">
                  We categorize and rank matched donors based strictly on closest district distance and divisional locations within Bangladesh.
                </p>
              </div>

              <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-xs text-center space-y-3">
                <div className="w-11 h-11 bg-red-50 text-red-600 rounded-xl flex items-center justify-center mx-auto">
                  <Building2 className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Hospital Stocks</h4>
                <p className="text-slate-500 text-xs leading-relaxed">
                  Hospital administrators update on-board shelf blood stock indices regularly. Automatic warning features alert admins if units fall below safe standards.
                </p>
              </div>
            </section>
          </div>
        )}

        {/* ========================================================
            LOGIN VIEW
            ======================================================== */}
        {currentPage === 'login' && (
          <div className="max-w-md mx-auto bg-white border border-slate-100 rounded-2xl shadow-xl shadow-slate-200/40 p-8 space-y-8 animate-fade-in" id="login_form_block">
            <div className="text-center space-y-2.5">
              <div className="w-12 h-12 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center mx-auto shadow-sm border border-red-100">
                <User className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-extrabold text-slate-900 tracking-tight">Secure Access Log In</h3>
              <p className="text-slate-500 text-xs leading-relaxed max-w-xs mx-auto">Verify credentials to manage your donation status, post urgencies, or synchronize hospital stock inventories.</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-5" id="login_form">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Email Address</label>
                <input 
                  type="email" 
                  value={authEmail} 
                  onChange={(e) => setAuthEmail(e.target.value)}
                  placeholder="e.g., sabina@example.bd"
                  className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800"
                  required
                  id="login_email"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Password</label>
                <input 
                  type="password" 
                  value={authPassword} 
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800"
                  required
                  id="login_pass"
                />
              </div>

              <button 
                type="submit" 
                className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-extrabold uppercase tracking-wider text-xs rounded-xl shadow-md shadow-red-500/10 hover:shadow-lg transition-all cursor-pointer active:scale-95"
                id="login_submit"
              >
                Sign In
              </button>
            </form>

            <div className="text-center text-xs text-slate-500 pt-4.5 border-t border-slate-100">
              New to BloodReach BD?{" "}
              <button onClick={() => setCurrentPage('register')} className="text-red-600 font-bold hover:underline cursor-pointer">
                Create Account Now
              </button>
            </div>
          </div>
        )}

        {/* ========================================================
            REGISTER VIEW
            =======        {currentPage === 'register' && (
          <div className="max-w-lg mx-auto bg-white border border-slate-100 rounded-2xl shadow-xl shadow-slate-200/40 p-8 space-y-8 animate-fade-in" id="register_form_block">
            <div className="text-center space-y-2.5">
              <div className="w-12 h-12 bg-rose-50 text-red-600 rounded-2xl flex items-center justify-center mx-auto border border-rose-100 shadow-sm">
                <PlusCircle className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-extrabold text-slate-900 tracking-tight">Platform Registration</h3>
              <p className="text-slate-500 text-xs leading-relaxed max-w-sm mx-auto">Join the national clinical blood grid and map live lifelines across Bangladesh.</p>
            </div>

            <form onSubmit={handleRegister} className="space-y-5" id="register_form">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-[10px] font-bold text-slate-550 uppercase tracking-widest mb-1.5">Full Name</label>
                  <input 
                    type="text" 
                    value={authName} 
                    onChange={(e) => setAuthName(e.target.value)}
                    placeholder="E.g., Sabina Yasmin"
                    className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800"
                    required
                    id="register_name"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-550 uppercase tracking-widest mb-1.5">Email Address</label>
                  <input 
                    type="email" 
                    value={authEmail} 
                    onChange={(e) => setAuthEmail(e.target.value)}
                    placeholder="name@email.com"
                    className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800"
                    required
                    id="register_email"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-[10px] font-bold text-slate-555 uppercase tracking-widest mb-1.5">Password</label>
                  <input 
                    type="password" 
                    value={authPassword} 
                    onChange={(e) => setAuthPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800"
                    required
                    id="register_pass"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-555 uppercase tracking-widest mb-1.5">Your Main Role</label>
                  <select 
                    value={authRole} 
                    onChange={(e) => setAuthRole(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800 cursor-pointer"
                    required
                    id="register_select_role"
                  >
                    <option value="donor">Donor (Can Donate Blood)</option>
                    <option value="seeker">Seeker (Requests Blood)</option>
                    <option value="hospital_admin">Hospital Admin (Coordinates Stock)</option>
                    <option value="super_admin">Super Admin (Overwatch Metrics)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-555 uppercase tracking-widest mb-1.5">Bangladeshi Home District</label>
                <select 
                  value={authDistrictId} 
                  onChange={(e) => setAuthDistrictId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800 cursor-pointer"
                  required
                  id="register_select_dist"
                >
                  {districts.map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.division_name})</option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-450 mt-1.5 font-medium leading-relaxed">
                  Required to route local donation requests and calculate division-proximity matches.
                </p>
              </div>

              <button 
                type="submit" 
                className="w-full py-3.5 bg-gradient-to-r from-red-650 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-extrabold uppercase tracking-wider text-xs rounded-xl shadow-md shadow-red-500/10 hover:shadow-lg transition-all cursor-pointer active:scale-95"
                id="register_submit"
              >
                Complete Account Registration
              </button>
            </form>

            <div className="text-center text-xs text-slate-500 pt-4.5 border-t border-slate-100">
              Already possess an identity?{" "}
              <button onClick={() => setCurrentPage('login')} className="text-red-600 font-bold hover:underline cursor-pointer">
                Proceed to Login
              </button>
            </div>
          </div>
        )}

        {/* ========================================================
            ROLE DASHBOARDS HUB
            ======================================================== */}
        {currentPage === 'dashboard' && token && currentUser && (
          <div className="space-y-6" id="dashboard_view">
            
            {/* Quick Profile Overview / Notification hub */}
            <section className="bg-slate-900 rounded-xl p-6 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-md" id="dashboard_header">
              <div className="space-y-1.5">
                <span className="bg-red-600/35 border border-red-500/30 text-red-300 rounded-full px-3 py-1 text-[10px] uppercase font-bold tracking-widest inline-block font-mono">
                  Role: {currentUser.role.replace('_', ' ')}
                </span>
                <h3 className="text-xl md:text-2xl font-bold tracking-tight">
                  Welcome Back, {currentUser.name}!
                </h3>
                <p className="text-slate-400 text-xs">
                  Email Identity: {currentUser.email} • Assigned District ID: #{currentUser.district_id || 'Not Assigned'}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button 
                  onClick={() => handleNavToSection('landing')} 
                  className="bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold px-4.5 py-2 rounded-xl border border-slate-700/60 transition-colors cursor-pointer"
                  id="btn_search_matching"
                >
                  Proximity Matches Search
                </button>
                <button 
                  onClick={handleLogout} 
                  className="bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-4.5 py-2 rounded-xl transition-colors shadow-sm cursor-pointer"
                >
                  Logout Session
                </button>
              </div>
            </section>

            {/* Notification alert inbox for the active account */}
            <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden" id="notification_inbox">
              <div className="border-b border-slate-100 p-5 bg-slate-50/60 flex items-center justify-between">
                <h4 className="text-[11px] font-extrabold text-slate-700 uppercase tracking-widest flex items-center gap-2">
                  <Bell className="w-4 h-4 text-red-550 shrink-0" />
                  Live Match Dispatch Feed ({notifications.length} logs)
                </h4>
                {notifications.some(n => !n.is_read) && (
                  <button 
                    onClick={markAllNotificationsRead} 
                    className="text-red-650 hover:text-red-700 text-[10px] uppercase tracking-wider font-extrabold cursor-pointer"
                  >
                    Mark all as read
                  </button>
                )}
              </div>
              <div className="max-h-60 overflow-y-auto divide-y divide-slate-100 text-xs" id="notif_list">
                {notifications.length === 0 ? (
                  <div className="text-center py-8 text-slate-400 font-medium">
                    No matching alerts routed to your account grid yet.
                  </div>
                ) : (
                  notifications.map(n => (
                    <div 
                      key={n.id} 
                      className={`p-4 flex items-start gap-3 transition-colors ${n.is_read ? 'bg-white opacity-80' : 'bg-red-50/20'}`}
                    >
                      <span className={`relative flex h-2 w-2 mt-1.5 shrink-0`}>
                        <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${n.is_read ? 'bg-slate-300' : 'bg-red-400'} opacity-75`}></span>
                        <span className={`relative inline-flex rounded-full h-2 w-2 ${n.is_read ? 'bg-slate-400' : 'bg-red-500'}`}></span>
                      </span>
                      <div className="space-y-1">
                        <p className={`text-slate-800 leading-relaxed ${!n.is_read ? 'font-bold' : 'font-semibold'}`}>
                          {n.message}
                        </p>
                        <span className="text-[9px] text-slate-450 font-semibold tracking-wide font-mono block uppercase">
                          Received: {new Date(n.created_at).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* ==================== DONOR DASHBOARD ==================== */}
            {currentUser.role === 'donor' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="donor_dashboard_layout">
                {/* Availability status column */}
                <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm space-y-6 lg:col-span-1" id="availability_controls">
                  <div className="space-y-4">
                    <h4 className="font-extrabold text-sm text-slate-900 border-b border-slate-50 pb-3 flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block animate-pulse"></span>
                      Availability Controller
                    </h4>
                    <div className="py-2 text-center">
                      <span className={`inline-flex items-center gap-2 text-[11px] font-extrabold px-4.5 py-2.5 rounded-xl border tracking-wider font-mono uppercase ${
                        donorProfile.is_available 
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                          : 'bg-rose-50 text-rose-700 border-rose-200'
                      }`}>
                        <span className={`relative flex h-2 w-2`}>
                          <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${donorProfile.is_available ? 'bg-emerald-400' : 'bg-rose-400'} opacity-75`}></span>
                          <span className={`relative inline-flex rounded-full h-2 w-2 ${donorProfile.is_available ? 'bg-emerald-500' : 'bg-rose-500'}`}></span>
                        </span>
                        {donorProfile.is_available ? 'ACTIVE & SEEKING' : 'INACTIVE / DND'}
                      </span>
                    </div>

                    <p className="text-slate-500 text-xs leading-relaxed">
                      While set to <strong className="text-slate-800">Active</strong>, our dispatch engine routes immediate matched notifications to you as requests occur in your local district.
                    </p>

                    <button 
                      onClick={toggleDonorAvailability}
                      className={`w-full py-3 font-extrabold text-xs rounded-xl transition-all tracking-wider uppercase cursor-pointer active:scale-95 shadow-sm ${
                        donorProfile.is_available 
                          ? 'bg-amber-600 hover:bg-amber-700 text-white shadow-amber-500/10' 
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-500/10'
                      }`}
                      id="btn_toggle_availability"
                    >
                      {donorProfile.is_available ? 'Go Offline' : 'Set Active Status'}
                    </button>
                  </div>
                </div>

                {/* Profile configurations details column */}
                <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm lg:col-span-2 space-y-5" id="profile_details_form">
                  <h4 className="font-extrabold text-sm text-slate-900 border-b border-slate-50 pb-3">
                    Configure Blood Group and History records
                  </h4>

                  <form onSubmit={updateDonorProfileDetails} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Donor Blood Group</label>
                        <select 
                          value={donorProfile.blood_group}
                          onChange={(e) => setDonorProfile(prev => ({ ...prev, blood_group: e.target.value }))}
                          className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800 cursor-pointer"
                          id="donor_form_bg"
                        >
                          {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => (
                            <option key={bg} value={bg}>{bg}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Last Donation Date</label>
                        <input 
                          type="date"
                          value={donorProfile.last_donated}
                          onChange={(e) => setDonorProfile(prev => ({ ...prev, last_donated: e.target.value }))}
                          className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800"
                          id="donor_form_date"
                        />
                        <span className="text-[10px] text-slate-450 mt-1.5 font-medium block">Leave empty if you are a first-time donor.</span>
                      </div>
                    </div>

                    <div className="pt-2">
                      <button 
                        type="submit"
                        className="bg-red-650 hover:bg-red-700 text-white text-xs font-extrabold uppercase tracking-wider py-3 px-5 rounded-xl cursor-pointer shadow-md shadow-red-500/10 hover:shadow-lg transition-all active:scale-95"
                        id="donor_form_submit"
                      >
                        Save Configuration Records
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* ==================== SEEKER DASHBOARD ==================== */}
            {currentUser.role === 'seeker' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="seeker_dashboard_layout">
                {/* Form to open blood request */}
                <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm lg:col-span-1 space-y-5" id="create_request_panel">
                  <div className="border-b border-slate-50 pb-3.5">
                    <h4 className="font-extrabold text-sm text-slate-900 tracking-tight">Create Immediate Blood Request</h4>
                    <p className="text-slate-500 text-[11px] mt-1 leading-relaxed">This will dispatch urgent match notices to matching online donors in the selected district.</p>
                  </div>

                  <form onSubmit={createBloodRequest} className="space-y-4" id="seeker_req_form">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Required Blood Group</label>
                      <select 
                        value={reqBloodGroup}
                        onChange={(e) => setReqBloodGroup(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800 cursor-pointer"
                        id="seeker_req_bg"
                      >
                        {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => (
                          <option key={bg} value={bg}>{bg}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-3.5">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Units Needed</label>
                        <input 
                          type="number"
                          min="1"
                          max="20"
                          value={reqUnits}
                          onChange={(e) => setReqUnits(parseInt(e.target.value) || 1)}
                          className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800"
                          required
                          id="seeker_req_units"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Urgency Level</label>
                        <select 
                          value={reqUrgency}
                          onChange={(e) => setReqUrgency(e.target.value as any)}
                          className={`w-full bg-slate-50 border hover:border-slate-300 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold cursor-pointer ${
                            reqUrgency === 'Critical' 
                              ? 'border-red-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 text-red-700' 
                              : reqUrgency === 'High' 
                                ? 'border-amber-300 focus:border-amber-500 focus:ring-4 focus:ring-amber-500/5 text-amber-700' 
                                : 'border-slate-200 focus:border-slate-500 focus:ring-4 focus:ring-slate-500/5 text-slate-800'
                          }`}
                          id="seeker_req_urgency"
                        >
                          <option value="Normal">Normal Priority</option>
                          <option value="High">High Urgency</option>
                          <option value="Critical">Critical Emergency</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Target District</label>
                      <select 
                        value={reqDistrictId}
                        onChange={(e) => setReqDistrictId(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 rounded-xl p-3 text-sm focus:outline-none transition-all font-semibold text-slate-800 cursor-pointer"
                        id="seeker_req_dist"
                      >
                        {districts.map(d => (
                          <option key={d.id} value={d.id}>{d.name} ({d.division_name})</option>
                        ))}
                      </select>
                    </div>

                    <button 
                      type="submit"
                      className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-extrabold uppercase tracking-wider text-xs rounded-xl shadow-md shadow-red-500/10 hover:shadow-lg transition-all cursor-pointer active:scale-95"
                      id="seeker_req_submit"
                    >
                      Dispatch Urgency Alert
                    </button>
                  </form>
                </div>

                {/* Seeker request log / active lists */}
                <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm lg:col-span-2 space-y-4" id="seeker_requests_log">
                  <h4 className="font-extrabold text-sm text-slate-900 border-b border-slate-50 pb-3 flex items-center justify-between">
                    <span>Dispatch History & Match States</span>
                    <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider">Historical Logs</span>
                  </h4>

                  <div className="space-y-4 max-h-[460px] overflow-y-auto pr-1" id="seeker_rows_feed">
                    {allRequests.filter(r => r.seeker_id === currentUser.id).length === 0 ? (
                      <div className="text-center py-10 text-slate-400">
                        You have not opened or dispatched any blood request alert requests as-yet.
                      </div>
                    ) : (
                      allRequests.filter(r => r.seeker_id === currentUser.id).map(req => (
                        <div key={req.id} className="border border-slate-100 rounded-xl p-4 bg-slate-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <span className="w-8 h-8 rounded-lg bg-slate-900 text-white font-black text-xs flex items-center justify-center">
                                {req.blood_group}
                              </span>
                              <div>
                                <h5 className="font-bold text-slate-900 text-sm">
                                  {req.units} Blood Unit{req.units > 1 ? 's' : ''} requested
                                </h5>
                                <p className="text-[11px] text-slate-500">
                                  Alert District: {req.district?.name || `#${req.district_id}`}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-2.5">
                              <span className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded-full ${
                                req.urgency === 'Critical' ? 'bg-rose-100 text-rose-800' : 'bg-slate-105 text-slate-600'
                              }`}>
                                {req.urgency} Urgency
                              </span>
                              <span className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded-full ${
                                req.status === 'pending' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                              }`}>
                                {req.status}
                              </span>
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center gap-2">
                            <button 
                              onClick={() => {
                                setFinderBloodGroup(req.blood_group);
                                setFinderDistrictId(req.district_id.toString());
                                setCurrentPage('landing');
                                setTimeout(() => {
                                  document.getElementById('donor_finder_card')?.scrollIntoView({ behavior: 'smooth' });
                                }, 300);
                              }}
                              className="bg-slate-150 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold py-1.8 px-3 rounded-lg transition-colors cursor-pointer"
                              title="Search proximity ranked matches for this particular alert criteria"
                            >
                              Scan Matches
                            </button>
                            
                            {req.status === 'pending' && (
                              <button 
                                onClick={() => fulfillRequest(req.id)}
                                className="bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold py-1.8 px-3 rounded-lg transition-colors cursor-pointer"
                              >
                                Mark Fulfilled
                              </button>
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* ==================== HOSPITAL ADMIN DASHBOARD ==================== */}
            {currentUser.role === 'hospital_admin' && (
              <div className="space-y-6" id="hospital_dashboard_layout">
                {/* Hospital selection details */}
                <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm space-y-5" id="hospital_identity_overview">
                  <div className="border-b border-slate-100 pb-4.5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-rose-50 text-red-600 rounded-xl flex items-center justify-center border border-rose-100 shadow-xs shrink-0">
                        <Building2 className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-sm text-slate-900 tracking-tight">
                          {selectedHospital ? selectedHospital.name : 'Unassigned Hospital Hub'}
                        </h4>
                        <p className="text-slate-455 text-[11px] mt-0.5">
                          Location: <strong className="text-slate-700 font-semibold">{selectedHospital?.district_name || 'Dhaka'}</strong> • Admin ID: <span className="font-mono bg-slate-50 px-1.5 py-0.5 rounded border border-slate-150">#{currentUser.id}</span>
                        </p>
                      </div>
                    </div>

                    <div className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] uppercase font-extrabold tracking-wider py-1.5 px-3.5 rounded-xl font-mono self-start sm:self-auto">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
                      Stock Grid Connected
                    </div>
                  </div>

                  {selectedHospital ? (
                    <div className="space-y-4">
                      <h5 className="text-slate-700 text-xs font-bold uppercase tracking-wider">Live Inventory Tracker (Capacity Units)</h5>
                      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-3" id="inventory_cards">
                        {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => {
                          const item = hospitalInventory.find(i => i.blood_group === bg);
                          const count = item ? item.units_available : 0;
                          const isLow = count <= 3;

                          return (
                            <div 
                              key={bg} 
                              className={`border rounded-2xl p-4 text-center transition-all hover:scale-[1.02] ${
                                isLow 
                                  ? 'bg-rose-50/40 border-red-200 shadow-xs shadow-red-100/30' 
                                  : 'bg-white border-slate-150 hover:shadow-md hover:shadow-slate-100'
                              }`}
                            >
                              <span className={`block text-xs font-bold uppercase tracking-widest ${isLow ? 'text-red-650' : 'text-slate-450'}`}>{bg}</span>
                              <span className={`block text-2xl font-extrabold my-1 font-mono ${isLow ? 'text-red-700' : 'text-slate-900'}`}>{count}</span>
                              
                              {/* Stock modifiers buttons */}
                              <div className="flex items-center justify-center gap-1.5 pt-2 border-t border-slate-100/60 mt-2">
                                <button 
                                  onClick={() => changeHospitalStockUnits(bg, count, -1)}
                                  className="w-6 h-6 rounded-lg bg-white border border-slate-200 text-slate-650 font-bold hover:bg-red-50 hover:text-red-600 hover:border-red-200 flex items-center justify-center text-sm leading-none shrink-0 transition-colors cursor-pointer"
                                  title="Decrease Stock"
                                >
                                  -
                                </button>
                                <button 
                                  onClick={() => changeHospitalStockUnits(bg, count, 1)}
                                  className="w-6 h-6 rounded-lg bg-white border border-slate-200 text-slate-650 font-bold hover:bg-emerald-50 hover:text-emerald-650 hover:border-emerald-250 flex items-center justify-center text-sm leading-none shrink-0 transition-colors cursor-pointer"
                                  title="Increase Stock"
                                >
                                  +
                                </button>
                              </div>

                              {isLow && (
                                <span className="inline-block text-[8px] font-extrabold text-red-600 bg-red-100/55 px-2 py-0.5 rounded-md mt-2.5 tracking-wider uppercase font-mono animate-pulse">
                                  Critical Low
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-6 text-slate-500">
                      No managed hospital has been bound to your administrator ID in raw data seeding. Please contact system admin.
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ==================== SUPER ADMIN DASHBOARD ==================== */}
            {currentUser.role === 'super_admin' && (
              <div className="space-y-6" id="super_admin_dashboard_layout">
                {/* Visual statistics grid */}
                <h4 className="font-extrabold text-sm text-slate-900 tracking-tight">Real-time Platform Core Indicators</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4.5" id="stats_panel">
                  <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-sm hover:scale-[1.01] transition-all">
                    <span className="text-blue-600 text-[10px] font-bold block uppercase tracking-widest font-mono">Total users</span>
                    <span className="text-3xl font-extrabold text-slate-900 mt-1 block font-mono">{analytics ? analytics.total_users : '...'}</span>
                  </div>
                  <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-sm hover:scale-[1.01] transition-all">
                    <span className="text-emerald-700 text-[10px] font-bold block uppercase tracking-widest font-mono">Active Donors</span>
                    <span className="text-3xl font-extrabold text-emerald-600 mt-1 block font-mono">
                      {analytics ? `${analytics.active_donors} / ${analytics.total_donors}` : '...'}
                    </span>
                  </div>
                  <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-sm hover:scale-[1.01] transition-all">
                    <span className="text-amber-700 text-[10px] font-bold block uppercase tracking-widest font-mono font-bold">Pending Alerts</span>
                    <span className="text-3xl font-extrabold text-slate-900 mt-1 block font-mono">
                      {analytics ? `${analytics.pending_requests} / ${analytics.total_requests}` : '...'}
                    </span>
                  </div>
                  <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-sm hover:scale-[1.01] transition-all">
                    <span className="text-rose-650 text-[10px] font-bold block uppercase tracking-widest font-mono font-bold">Fulfilled matching</span>
                    <span className="text-3xl font-extrabold text-red-600 mt-1 block font-mono">{analytics ? analytics.fulfilled_requests : '...'}</span>
                  </div>
                </div>

                {/* Users overview spreadsheet */}
                <div className="bg-white border border-slate-150 rounded-2xl shadow-xs p-6" id="users_table_tab">
                  <div className="border-b border-slate-100 pb-4 mb-4">
                    <h5 className="font-bold text-slate-900 text-sm">System accounts database</h5>
                    <p className="text-slate-500 text-xs mt-0.5">Summary of all registered users on the system (Admin only access)</p>
                  </div>

                  <div className="overflow-x-auto" id="users_scroll_pane">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 text-slate-450 uppercase font-black">
                          <th className="py-2.5 px-3">ID</th>
                          <th className="py-2.5 px-3">Name</th>
                          <th className="py-2.5 px-3">Email Address</th>
                          <th className="py-2.5 px-3">Target User Role</th>
                          <th className="py-2.5 px-3">District Location</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100" id="users_rows">
                        {usersList.map(u => (
                          <tr key={u.id} className="hover:bg-slate-50/50">
                            <td className="py-2.5 px-3 font-mono text-slate-500">#{u.id}</td>
                            <td className="py-2.5 px-3 font-semibold text-slate-800">{u.name}</td>
                            <td className="py-2.5 px-3 text-slate-500">{u.email}</td>
                            <td className="py-2.5 px-3">
                              <span className={`inline-block px-2.5 py-0.5 rounded-full text-[9px] uppercase font-bold ${
                                u.role === 'super_admin' ? 'bg-amber-100 text-amber-800' :
                                u.role === 'hospital_admin' ? 'bg-blue-100 text-blue-800' :
                                u.role === 'donor' ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-800'
                              }`}>
                                {u.role.replace('_', ' ')}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-slate-650">{u.district_name || 'Not set'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

      </div> {/* max-w-7xl */}
    </div> {/* scroll_viewport */}
  </main>

      {/* ─── PLATFORM FOOTER SYSTEM GREETING ─── */}
      <footer className="bg-white border-t border-rose-100 py-6 text-center text-xs text-slate-500" id="app_footer_nav">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p className="font-medium text-slate-700">
            Blood Reach BD • Real-Time Blood Availability & Donor Matching Platform
          </p>
          <p className="text-[10px] text-slate-400">
            Developed strictly with custom proximity routing for divisions and districts in Bangladesh.
          </p>
        </div>
      </footer>
    </div>
  );
}
