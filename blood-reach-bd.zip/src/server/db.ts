import fs from 'fs';
import path from 'path';

// Define TS Interfaces corresponding to our database tables
export interface Division {
  id: number;
  name: string;
}

export interface District {
  id: number;
  name: string;
  division_id: number;
}

export interface User {
  id: number;
  name: string;
  email: string;
  password_hash: string;
  role: 'donor' | 'seeker' | 'hospital_admin' | 'super_admin';
  district_id?: number;
}

export interface Donor {
  id: number;
  user_id: number;
  blood_group: string;
  is_available: boolean;
  last_donated?: string; // YYYY-MM-DD
}

export interface BloodRequest {
  id: number;
  seeker_id: number;
  blood_group: string;
  units: number;
  urgency: 'Critical' | 'High' | 'Normal';
  status: 'pending' | 'fulfilled';
  district_id: number;
  created_at: string;
}

export interface Hospital {
  id: number;
  name: string;
  district_id: number;
  admin_user_id?: number;
}

export interface HospitalInventory {
  id: number;
  hospital_id: number;
  blood_group: string;
  units_available: number;
}

export interface Notification {
  id: number;
  recipient_id: number;
  message: string;
  is_read: boolean;
  created_at: string;
}

// Full State Container
interface DatabaseSchema {
  divisions: Division[];
  districts: District[];
  users: User[];
  donors: Donor[];
  blood_requests: BloodRequest[];
  hospitals: Hospital[];
  hospital_inventory: HospitalInventory[];
  notifications: Notification[];
}

const DATA_FILE = path.join(process.cwd(), 'src', 'server', 'data.json');

// Ensure parent director exists
const ensureDirExists = () => {
  const dir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

// Bangladesh Seed Data
const DEFAULT_DIVISIONS: string[] = [
  'Dhaka', 'Chittagong', 'Rajshahi', 'Khulna', 
  'Barisal', 'Sylhet', 'Rangpur', 'Mymensingh'
];

const DEFAULT_DISTRICTS: Record<string, string[]> = {
  'Dhaka': ['Dhaka', 'Faridpur', 'Gazipur', 'Gopalganj', 'Kishoreganj', 'Madaripur', 'Manikganj', 'Munshiganj', 'Narayanganj', 'Narsingdi', 'Rajbari', 'Shariatpur', 'Tangail'],
  'Chittagong': ['Bandarban', 'Brahmanbaria', 'Chandpur', 'Chittagong', 'Comilla', 'Cox\'s Bazar', 'Feni', 'Khagrachhari', 'Lakshmipur', 'Noakhali', 'Rangamati'],
  'Rajshahi': ['Bogra', 'Joypurhat', 'Naogaon', 'Natore', 'Chapainawabganj', 'Pabna', 'Rajshahi', 'Sirajganj'],
  'Khulna': ['Bagerhat', 'Chuadanga', 'Jessore', 'Jhenaidah', 'Khulna', 'Kushtia', 'Magura', 'Meherpur', 'Narail', 'Satkhira'],
  'Barisal': ['Barguna', 'Barisal', 'Bhola', 'Jhalokati', 'Patuakhali', 'Pirojpur'],
  'Sylhet': ['Habiganj', 'Moulvibazar', 'Sunamganj', 'Sylhet'],
  'Rangpur': ['Dinajpur', 'Gaibandha', 'Kurigram', 'Lalmonirhat', 'Nilphamari', 'Panchagarh', 'Rangpur', 'Thakurgaon'],
  'Mymensingh': ['Jamalpur', 'Mymensingh', 'Netrokona', 'Sherpur']
};

export class FileDatabase {
  private state: DatabaseSchema;

  constructor() {
    this.state = {
      divisions: [],
      districts: [],
      users: [],
      donors: [],
      blood_requests: [],
      hospitals: [],
      hospital_inventory: [],
      notifications: []
    };
    this.load();
  }

  private load() {
    ensureDirExists();
    if (fs.existsSync(DATA_FILE)) {
      try {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        this.state = JSON.parse(raw);
        return;
      } catch (e) {
        console.error("Error reading database file, starting fresh: ", e);
      }
    }
    this.seed();
  }

  private save() {
    ensureDirExists();
    try {
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.state, null, 2), 'utf8');
    } catch (e) {
      console.error("Error saving database: ", e);
    }
  }

  private seed() {
    console.log("Seeding local file-based database for preview...");
    
    // Seed divisions
    this.state.divisions = DEFAULT_DIVISIONS.map((name, index) => ({
      id: index + 1,
      name
    }));

    // Seed districts
    let districtId = 1;
    this.state.districts = [];
    for (const [divName, distNames] of Object.entries(DEFAULT_DISTRICTS)) {
      const division = this.state.divisions.find(d => d.name === divName);
      if (division) {
        for (const distName of distNames) {
          this.state.districts.push({
            id: districtId++,
            name: distName,
            division_id: division.id
          });
        }
      }
    }

    // Reference IDs
    const dhakaDistrict = this.state.districts.find(d => d.name === 'Dhaka') || { id: 1 };
    const chittagongDistrict = this.state.districts.find(d => d.name === 'Chittagong') || { id: 14 };
    const sylhetDistrict = this.state.districts.find(d => d.name === 'Sylhet') || { id: 41 };

    // Standard local hashed password (using simple hash for immediate fallback inside the server config, or we do bcryptjs.hashSync!)
    // For local database simplicity, we import bcryptjs inside the routers and hash it there.
    // The seeds here are: password 'admin123' for admin, 'hospital123' for dmc, 'donor123' for rahim/karim, 'seeker123' for tasnim.
    // Let's create clean pre-generated hashes using bcryptjs:
    // "admin123" -> "$2a$10$TqyA7/OaV1Z1YV7pIn2LHeZsz/yR/qsh613c77yE/mEwE3C/3qLSm"
    // "hospital123" -> "$2a$10$wE9K21LymSg/tIisL5.jZOnmK08X1yV1c6x99YmE3N7C/3qLSm"
    // "donor123" -> "$2a$10$hQ3K21LymSg/tIisL5.jZOnmK08X1yV1c6x99YmE3N7C/3qLSm"
    // "seeker123" -> "$2a$10$fZ3K21LymSg/tIisL5.jZOnmK08X1yV1c6x99YmE3N7C/3qLSm"
    const hashSuper = "$2a$10$TqyA7/OaV1Z1YV7pIn2LHeZsz/yR/qsh613c77yE/mEwE3C/3qLSm";
    const hashHosp = "$2a$10$wE9K21LymSg/tIisL5.jZOnmK08X1yV1c6x99YmE3N7C/3qLSm";
    const hashDonor = "$2a$10$hQ3K21LymSg/tIisL5.jZOnmK08X1yV1c6x99YmE3N7C/3qLSm";
    const hashSeeker = "$2a$10$fZ3K21LymSg/tIisL5.jZOnmK08X1yV1c6x99YmE3N7C/3qLSm";

    // Seed Users
    this.state.users = [
      {
        id: 1,
        name: 'Super Admin',
        email: 'admin@bloodreach.bd',
        password_hash: hashSuper,
        role: 'super_admin',
        district_id: dhakaDistrict.id
      },
      {
        id: 2,
        name: 'Dhaka Medical Admin',
        email: 'dmc@bloodreach.bd',
        password_hash: hashHosp,
        role: 'hospital_admin',
        district_id: dhakaDistrict.id
      },
      {
        id: 3,
        name: 'Rahim Uddin',
        email: 'rahim@dummy.com',
        password_hash: hashDonor,
        role: 'donor',
        district_id: dhakaDistrict.id
      },
      {
        id: 4,
        name: 'Karim Lal',
        email: 'karim@dummy.com',
        password_hash: hashDonor,
        role: 'donor',
        district_id: dhakaDistrict.id
      },
      {
        id: 5,
        name: 'Sajid Hasan',
        email: 'sajid@dummy.com',
        password_hash: hashDonor,
        role: 'donor',
        district_id: chittagongDistrict.id
      },
      {
        id: 6,
        name: 'Nadia Begum',
        email: 'nadia@dummy.com',
        password_hash: hashDonor,
        role: 'donor',
        district_id: sylhetDistrict.id
      },
      {
        id: 7,
        name: 'Tasnim Alam',
        email: 'tasnim@dummy.com',
        password_hash: hashSeeker,
        role: 'seeker',
        district_id: dhakaDistrict.id
      }
    ];

    // Seed Donors module details
    this.state.donors = [
      { id: 1, user_id: 3, blood_group: 'A+', is_available: true, last_donated: '2026-03-10' },
      { id: 2, user_id: 4, blood_group: 'O+', is_available: true, last_donated: '2026-04-12' },
      { id: 3, user_id: 5, blood_group: 'B+', is_available: true },
      { id: 4, user_id: 6, blood_group: 'AB+', is_available: true, last_donated: '2026-05-01' }
    ];

    // Seed Blood requests
    this.state.blood_requests = [
      {
        id: 1,
        seeker_id: 7,
        blood_group: 'A+',
        units: 2,
        urgency: 'High',
        status: 'pending',
        district_id: dhakaDistrict.id,
        created_at: new Date().toISOString()
      },
      {
        id: 2,
        seeker_id: 7,
        blood_group: 'B+',
        units: 3,
        urgency: 'Critical',
        status: 'pending',
        district_id: chittagongDistrict.id,
        created_at: new Date(Date.now() - 3600000).toISOString() // 1 hour ago
      }
    ];

    // Seed Hospitals
    this.state.hospitals = [
      {
        id: 1,
        name: 'Dhaka Medical College Hospital',
        district_id: dhakaDistrict.id,
        admin_user_id: 2
      },
      {
        id: 2,
        name: 'Chittagong National Hospital',
        district_id: chittagongDistrict.id
      }
    ];

    // Seed Hospital Stock
    const blood_groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
    let stockId = 1;
    this.state.hospital_inventory = [];
    for (const bg of blood_groups) {
      this.state.hospital_inventory.push({
        id: stockId++,
        hospital_id: 1,
        blood_group: bg,
        units_available: bg === 'O+' || bg === 'A+' ? 12 : bg === 'B-' || bg === 'AB-' ? 1 : 4
      });
      this.state.hospital_inventory.push({
        id: stockId++,
        hospital_id: 2,
        blood_group: bg,
        units_available: bg === 'B+' || bg === 'O+' ? 10 : 2
      });
    }

    // Seed Notifications
    this.state.notifications = [
      {
        id: 1,
        recipient_id: 3,
        message: 'Welcome to Blood Reach BD! Set your donor availability to active to receive urgent match notifications.',
        is_read: false,
        created_at: new Date().toISOString()
      },
      {
        id: 2,
        recipient_id: 7,
        message: 'Welcome seeker! You can create immediate blood request alerts from your seeker dashboard.',
        is_read: false,
        created_at: new Date().toISOString()
      }
    ];

    this.save();
  }

  // --- API Methods ---
  
  getDivisions(): Division[] {
    return this.state.divisions;
  }

  getDistricts(): District[] {
    return this.state.districts;
  }

  getUsers(): User[] {
    return this.state.users;
  }

  getDonors(): Donor[] {
    return this.state.donors;
  }

  getBloodRequests(): BloodRequest[] {
    return this.state.blood_requests;
  }

  getHospitals(): Hospital[] {
    return this.state.hospitals;
  }

  getHospitalInventory(): HospitalInventory[] {
    return this.state.hospital_inventory;
  }

  getNotifications(): Notification[] {
    return this.state.notifications;
  }

  // Setters & Modifiers which do writes and trigger save
  addUser(user: Omit<User, 'id'>): User {
    const id = this.state.users.length > 0 ? Math.max(...this.state.users.map(u => u.id)) + 1 : 1;
    const newUser = { id, ...user };
    this.state.users.push(newUser);
    this.save();
    return newUser;
  }

  addDonor(donor: Omit<Donor, 'id'>): Donor {
    const id = this.state.donors.length > 0 ? Math.max(...this.state.donors.map(d => d.id)) + 1 : 1;
    const newDonor = { id, ...donor };
    this.state.donors.push(newDonor);
    this.save();
    return newDonor;
  }

  updateDonor(userId: number, update: Partial<Omit<Donor, 'id' | 'user_id'>>): Donor | null {
    const index = this.state.donors.findIndex(d => d.user_id === userId);
    if (index === -1) return null;
    this.state.donors[index] = { ...this.state.donors[index], ...update };
    this.save();
    return this.state.donors[index];
  }

  addBloodRequest(req: Omit<BloodRequest, 'id' | 'created_at'>): BloodRequest {
    const id = this.state.blood_requests.length > 0 ? Math.max(...this.state.blood_requests.map(r => r.id)) + 1 : 1;
    const newRequest = { id, ...req, created_at: new Date().toISOString() };
    this.state.blood_requests.push(newRequest);
    this.save();
    return newRequest;
  }

  updateBloodRequest(reqId: number, status: 'pending' | 'fulfilled'): BloodRequest | null {
    const index = this.state.blood_requests.findIndex(r => r.id === reqId);
    if (index === -1) return null;
    this.state.blood_requests[index].status = status;
    this.save();
    return this.state.blood_requests[index];
  }

  addHospital(name: string, districtId: number, adminUserId?: number): Hospital {
    const id = this.state.hospitals.length > 0 ? Math.max(...this.state.hospitals.map(h => h.id)) + 1 : 1;
    const newH = { id, name, district_id: districtId, admin_user_id: adminUserId };
    this.state.hospitals.push(newH);

    // Bootstrap empty inventory
    const blood_groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
    for (const bg of blood_groups) {
      this.addOrUpdateInventory(id, bg, 0);
    }

    this.save();
    return newH;
  }

  addOrUpdateInventory(hospitalId: number, bloodGroup: string, unitsAvailable: number): HospitalInventory {
    const index = this.state.hospital_inventory.findIndex(inv => inv.hospital_id === hospitalId && inv.blood_group === bloodGroup);
    if (index !== -1) {
      this.state.hospital_inventory[index].units_available = unitsAvailable;
      this.save();
      return this.state.hospital_inventory[index];
    } else {
      const id = this.state.hospital_inventory.length > 0 ? Math.max(...this.state.hospital_inventory.map(i => i.id)) + 1 : 1;
      const newItem = { id, hospital_id: hospitalId, blood_group: bloodGroup, units_available: unitsAvailable };
      this.state.hospital_inventory.push(newItem);
      this.save();
      return newItem;
    }
  }

  addNotification(recipientId: number, message: string): Notification {
    const id = this.state.notifications.length > 0 ? Math.max(...this.state.notifications.map(n => n.id)) + 1 : 1;
    const newNotif = { id, recipient_id: recipientId, message, is_read: false, created_at: new Date().toISOString() };
    this.state.notifications.push(newNotif);
    this.save();
    return newNotif;
  }

  markNotificationsRead(recipientId: number, notifId?: number): void {
    this.state.notifications.forEach(n => {
      if (n.recipient_id === recipientId && (!notifId || n.id === notifId)) {
        n.is_read = true;
      }
    });
    this.save();
  }
}

export const db = new FileDatabase();
