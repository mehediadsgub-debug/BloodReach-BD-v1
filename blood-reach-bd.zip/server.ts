import express, { Request, Response, NextFunction } from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import jwt from "jsonwebtoken";
import bcryptjs from "bcryptjs";
import { db } from "./src/server/db.ts";

const app = express();
const PORT = 3000;
const JWT_SECRET = "b40d4ea93bd855bb95b2cd645f653457d5985b82c6fd3dcecb237e810a9f60a1";

// Middleware
app.use(express.json());

// Token interfaces
interface DecodedToken {
  userId: number;
  role: string;
  email: string;
}

export interface AuthRequest extends Request {
  user?: DecodedToken;
}

// Security Middleware for Authenticated user
const requireAuth = (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Unauthorized: Missing authentication token" });
  }

  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as DecodedToken;
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ error: "Unauthorized: Invalid or expired token" });
  }
};

// ─── AUTH ENDPOINTS ───
app.post("/api/auth/register", (req, res) => {
  const { name, email, password, role, district_id } = req.body;
  
  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: "Please enter all required fields" });
  }

  const normalizedEmail = email.toLowerCase().trim();
  const existingUser = db.getUsers().find(u => u.email === normalizedEmail);
  if (existingUser) {
    return res.status(400).json({ error: "Email already registered" });
  }

  const salt = bcryptjs.genSaltSync(10);
  const passwordHash = bcryptjs.hashSync(password, salt);

  const user = db.addUser({
    name,
    email: normalizedEmail,
    password_hash: passwordHash,
    role,
    district_id: district_id ? parseInt(district_id) : undefined
  });

  if (role === "donor") {
    db.addDonor({
      user_id: user.id,
      blood_group: "A+", // default
      is_available: true
    });
  }

  // Welcome Notification
  db.addNotification(user.id, `Welcome to Blood Reach BD, ${name}! Set up your user profile details to get started.`);

  res.status(201).json({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    district_id: user.district_id
  });
});

app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json( { error: "Please enter email and password" } );
  }

  const normalizedEmail = email.toLowerCase().trim();
  const user = db.getUsers().find(u => u.email === normalizedEmail);
  if (!user || !bcryptjs.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: "Incorrect email or password" });
  }

  const token = jwt.sign(
    { userId: user.id, role: user.role, email: user.email },
    JWT_SECRET,
    { expiresIn: "1d" }
  );

  res.json({
    access_token: token,
    token_type: "bearer",
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      district_id: user.district_id
    }
  });
});

// ─── DONOR ENDPOINTS ───
app.get("/api/donors", (req, res) => {
  const { blood_group, district_id, is_available_only } = req.query;
  const showUnavail = is_available_only === "false";

  let donorsList = db.getDonors();
  const usersList = db.getUsers();
  const districtsList = db.getDistricts();

  // Map user details to donor output
  let results = donorsList.map(donor => {
    const user = usersList.find(u => u.id === donor.user_id);
    const dist = districtsList.find(d => d.id === user?.district_id);
    return {
      ...donor,
      user: user ? {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        district_id: user.district_id,
        district_name: dist?.name || "Unknown"
      } : null
    };
  });

  if (!showUnavail) {
    results = results.filter(r => r.is_available);
  }
  if (blood_group) {
    results = results.filter(r => r.blood_group === blood_group);
  }
  if (district_id) {
    results = results.filter(r => r.user?.district_id === parseInt(district_id as string));
  }

  res.json(results);
});

app.put("/api/donor/update", requireAuth, (req: AuthRequest, res) => {
  const userObj = req.user!;
  if (userObj.role !== "donor") {
    return res.status(400).json({ error: "Only accounts registered as Donors can configure donor profiles" });
  }

  const { blood_group, is_available, last_donated } = req.body;
  let donor = db.getDonors().find(d => d.user_id === userObj.userId);
  if (!donor) {
    donor = db.addDonor({
      user_id: userObj.userId,
      blood_group: blood_group || "A+",
      is_available: is_available !== undefined ? is_available : true,
      last_donated: last_donated
    });
  } else {
    donor = db.updateDonor(userObj.userId, {
      blood_group: blood_group !== undefined ? blood_group : donor.blood_group,
      is_available: is_available !== undefined ? is_available : donor.is_available,
      last_donated: last_donated !== undefined ? last_donated : donor.last_donated
    })!;
  }

  res.json(donor);
});

app.patch("/api/donor/availability", requireAuth, (req: AuthRequest, res) => {
  const userObj = req.user!;
  if (userObj.role !== "donor") {
    return res.status(400).json({ error: "Only donors can modify donor availability status" });
  }

  const { is_available } = req.body;
  if (is_available === undefined) {
    return res.status(400).json({ error: "Availability state (is_available) is required" });
  }

  let donor = db.getDonors().find(d => d.user_id === userObj.userId);
  if (!donor) {
    donor = db.addDonor({
      user_id: userObj.userId,
      blood_group: "A+",
      is_available: is_available
    });
  } else {
    donor = db.updateDonor(userObj.userId, { is_available })!;
  }

  res.json(donor);
});

// ─── BLOOD REQUESTS ENDPOINTS ───
app.post("/api/requests", requireAuth, (req: AuthRequest, res) => {
  const userObj = req.user!;
  const { blood_group, units, urgency, district_id } = req.body;

  if (!blood_group || !units || !urgency || !district_id) {
    return res.status(400).json({ error: "All blood request details must be provided" });
  }

  const request = db.addBloodRequest({
    seeker_id: userObj.userId,
    blood_group,
    units: parseInt(units),
    urgency,
    status: "pending",
    district_id: parseInt(district_id)
  });

  // REAL-TIME MATCHING ALERTS
  // Send notifications to available matched donors in the district
  const matchedDonors = db.getDonors().filter(d => {
    if (!d.is_available || d.blood_group !== blood_group) return false;
    const donorUser = db.getUsers().find(u => u.id === d.user_id);
    return donorUser?.district_id === parseInt(district_id);
  });

  matchedDonors.forEach(donor => {
    db.addNotification(
      donor.user_id,
      `URGENT MATCH: A Critical/High blood request of group ${blood_group} was created in your district! Please check active alerts immediately.`
    );
  });

  res.status(201).json(request);
});

app.get("/api/requests", (req, res) => {
  const { district_id, blood_group, status } = req.query;

  let requests = db.getBloodRequests();
  const users = db.getUsers();
  const districts = db.getDistricts();

  let results = requests.map(r => {
    const seeker = users.find(u => u.id === r.seeker_id);
    const dist = districts.find(d => d.id === r.district_id);
    return {
      ...r,
      seeker: seeker ? {
        id: seeker.id,
        name: seeker.name,
        email: seeker.email
      } : null,
      district: dist ? {
        id: dist.id,
        name: dist.name
      } : null
    };
  });

  if (district_id) {
    results = results.filter(r => r.district_id === parseInt(district_id as string));
  }
  if (blood_group) {
    results = results.filter(r => r.blood_group === blood_group);
  }
  if (status) {
    results = results.filter(r => r.status === status);
  }

  // Priority Sort: Critical = 1, High = 2, Normal = 3
  const levelRank: Record<string, number> = { "Critical": 1, "High": 2, "Normal": 3 };
  results.sort((a, b) => {
    const diff = (levelRank[a.urgency] || 4) - (levelRank[b.urgency] || 4);
    if (diff !== 0) return diff;
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });

  res.json(results);
});

app.patch("/api/requests/:id", requireAuth, (req: AuthRequest, res) => {
  const userObj = req.user!;
  const id = parseInt(req.params.id);
  const { status } = req.body;

  if (!status || (status !== "pending" && status !== "fulfilled")) {
    return res.status(400).json({ error: "Invalid status, must be pending or fulfilled" });
  }

  const request = db.getBloodRequests().find(r => r.id === id);
  if (!request) {
    return res.status(404).json({ error: "Blood request not found" });
  }

  // Authorization check (seeker or super_admin or hospital_admin)
  if (request.seeker_id !== userObj.userId && userObj.role !== "super_admin" && userObj.role !== "hospital_admin") {
    return res.status(403).json({ error: "Permission Denied: Only the request host or admins can mark requests as fulfilled" });
  }

  const updated = db.updateBloodRequest(id, status);
  if (status === "fulfilled") {
    db.addNotification(request.seeker_id, `Your active blood request for ${request.units} units of ${request.blood_group} was successfully marked as fulfilled!`);
  }

  res.json(updated);
});

// ─── MATCHING ENDPOINT ───
app.get("/api/match", (req, res) => {
  const { blood_group, district_id } = req.query;

  if (!blood_group || !district_id) {
    return res.status(400).json({ error: "Please enter blood_group and district_id params" });
  }

  const distId = parseInt(district_id as string);
  const targetDist = db.getDistricts().find(d => d.id === distId);
  if (!targetDist) {
    return res.status(400).json({ error: "District not found in Bangladesh list" });
  }

  const donors = db.getDonors().filter(d => d.is_available && d.blood_group === blood_group);
  const users = db.getUsers();
  const districts = db.getDistricts();
  const divisions = db.getDivisions();

  const matched = donors.map(d => {
    const dUser = users.find(u => u.id === d.user_id);
    const dDist = districts.find(dist => dist.id === dUser?.district_id);
    const dDiv = divisions.find(div => div.id === dDist?.division_id);

    let rank = 3; // default: Other
    if (dUser?.district_id === distId) {
      rank = 1; // Same District
    } else if (dDist?.division_id === targetDist.division_id) {
      rank = 2; // Same Division
    }

    return {
      donor_id: d.id,
      name: dUser?.name || "Anonymous",
      email: dUser?.email || "",
      blood_group: d.blood_group,
      district: dDist?.name || "Unknown",
      division: dDiv?.name || "Unknown",
      is_available: d.is_available,
      proximity_rank: rank
    };
  });

  matched.sort((a, b) => a.proximity_rank - b.proximity_rank);
  res.json(matched);
});

// ─── HOSPITAL & INVENTORY ENDPOINTS ───
app.get("/api/hospitals", (req, res) => {
  const { district_id } = req.query;
  let list = db.getHospitals();
  if (district_id) {
    list = list.filter(h => h.district_id === parseInt(district_id as string));
  }
  const districts = db.getDistricts();
  const output = list.map(h => {
    const dist = districts.find(d => d.id === h.district_id);
    return {
      ...h,
      district_name: dist?.name || "Unknown"
    };
  });
  res.json(output);
});

app.get("/api/inventory", (req, res) => {
  const { hospital_id } = req.query;
  if (!hospital_id) {
    return res.status(400).json({ error: "hospital_id parameter is required" });
  }

  const items = db.getHospitalInventory().filter(i => i.hospital_id === parseInt(hospital_id as string));
  res.json(items);
});

app.post("/api/inventory", requireAuth, (req: AuthRequest, res) => {
  const userObj = req.user!;
  if (userObj.role !== "hospital_admin" && userObj.role !== "super_admin") {
    return res.status(403).json({ error: "Access Denied: Only Hospital Admins or Super Admins can configure hospital inventory" });
  }

  const { hospital_id, blood_group, units_available } = req.body;
  if (!hospital_id || !blood_group || units_available === undefined) {
    return res.status(400).json({ error: "hospital_id, blood_group and units_available are required" });
  }

  const parsedHospitalId = parseInt(hospital_id);
  const hospital = db.getHospitals().find(h => h.id === parsedHospitalId);
  if (!hospital) {
    return res.status(404).json({ error: "Hospital not found" });
  }

  if (userObj.role === "hospital_admin" && hospital.admin_user_id !== userObj.userId) {
    return res.status(403).json({ error: "Access Denied: You do not manage this specific hospitals inventory" });
  }

  const updatedUnits = parseInt(units_available);
  const item = db.addOrUpdateInventory(parsedHospitalId, blood_group, updatedUnits);

  // LOW STOCK ALERT TRIGGER
  if (updatedUnits <= 3) {
    db.addNotification(
      userObj.userId,
      `LOW STOCK ALERT: Stock for blood group "${blood_group}" in "${hospital.name}" is dangerously low (${updatedUnits} units)!`
    );
  }

  res.json(item);
});

// ─── NOTIFICATIONS ENDPOINTS ───
app.get("/api/notifications", requireAuth, (req: AuthRequest, res) => {
  const userObj = req.user!;
  const unreadOnly = req.query.only_unread === "true";

  let list = db.getNotifications().filter(n => n.recipient_id === userObj.userId);
  if (unreadOnly) {
    list = list.filter(n => !n.is_read);
  }

  list.sort((a,b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  res.json(list);
});

app.patch("/api/notifications/read", requireAuth, (req: AuthRequest, res) => {
  const userObj = req.user!;
  const { id } = req.body; // if empty, marks all as read

  db.markNotificationsRead(userObj.userId, id ? parseInt(id) : undefined);
  res.json({ success: true, message: "Notifications updated successfully" });
});

// ─── LOCATION HELPERS ───
app.get("/api/divisions", (req, res) => {
  res.json(db.getDivisions());
});

app.get("/api/districts", (req, res) => {
  const list = db.getDistricts();
  const divisions = db.getDivisions();
  const detailed = list.map(dist => {
    const div = divisions.find(d => d.id === dist.division_id);
    return {
      ...dist,
      division_name: div?.name || "Unknown"
    };
  });
  res.json(detailed);
});

// ─── ANALYTICS ───
app.get("/api/admin/analytics", requireAuth, (req: AuthRequest, res) => {
  const userObj = req.user!;
  if (userObj.role !== "super_admin") {
    return res.status(403).json({ error: "Access Denied: Super Admin role required" });
  }

  const users = db.getUsers();
  const donors = db.getDonors();
  const requests = db.getBloodRequests();
  const hospitals = db.getHospitals();

  res.json({
    total_users: users.length,
    total_donors: donors.length,
    active_donors: donors.filter(d => d.is_available).length,
    total_requests: requests.length,
    pending_requests: requests.filter(r => r.status === "pending").length,
    fulfilled_requests: requests.filter(r => r.status === "fulfilled").length,
    total_hospitals: hospitals.length
  });
});

app.get("/api/admin/users", requireAuth, (req: AuthRequest, res) => {
  const userObj = req.user!;
  if (userObj.role !== "super_admin") {
    return res.status(403).json({ error: "Access Denied" });
  }

  const users = db.getUsers().map(u => ({
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    district_id: u.district_id,
    district_name: db.getDistricts().find(d => d.id === u.district_id)?.name || "Not set"
  }));

  res.json(users);
});

// Vite Middleware integration for SPA static serving in production & compile-on-the-fly in development
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is booting on Port ${PORT} (Ingress Active)`);
  });
}

startServer();
