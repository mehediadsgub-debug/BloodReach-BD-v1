from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date

from ..database import get_db
from .. import models, schemas, auth

router = APIRouter(tags=["Donor Module"])

@router.get("/donors", response_model=List[schemas.DonorOut])
def get_donors(
    blood_group: Optional[str] = None,
    district_id: Optional[int] = None,
    is_available_only: bool = True,
    db: Session = Depends(get_db)
):
    query = db.query(models.Donor).join(models.User)
    
    if is_available_only:
        query = query.filter(models.Donor.is_available == True)
        
    if blood_group:
        query = query.filter(models.Donor.blood_group == blood_group)
        
    if district_id:
        query = query.filter(models.User.district_id == district_id)
        
    return query.all()

@router.put("/donor/update", response_model=schemas.DonorOut)
def update_donor_profile(
    profile_data: schemas.DonorUpdate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role != "donor":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current logged-in user is not configured as a blood donor"
        )
        
    donor = db.query(models.Donor).filter(models.Donor.user_id == current_user.id).first()
    if not donor:
        # Auto-create if somehow missing
        donor = models.Donor(user_id=current_user.id, blood_group="A+", is_available=True)
        db.add(donor)
        db.flush()
        
    if profile_data.blood_group is not None:
        donor.blood_group = profile_data.blood_group
    if profile_data.is_available is not None:
        donor.is_available = profile_data.is_available
    if profile_data.last_donated is not None:
        donor.last_donated = profile_data.last_donated
        
    db.commit()
    db.refresh(donor)
    return donor

@router.patch("/donor/availability", response_model=schemas.DonorOut)
def toggle_availability(
    is_available: bool,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role != "donor":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only donors can toggle their status availability"
        )
        
    donor = db.query(models.Donor).filter(models.Donor.user_id == current_user.id).first()
    if not donor:
        donor = models.Donor(user_id=current_user.id, blood_group="A+", is_available=is_available)
        db.add(donor)
    else:
        donor.is_available = is_available
        
    db.commit()
    db.refresh(donor)
    return donor
