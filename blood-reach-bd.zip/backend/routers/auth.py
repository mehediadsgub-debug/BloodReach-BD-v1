from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from datetime import timedelta

from ..database import get_db
from .. import models, schemas, auth

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/register", response_model=schemas.UserOut)
def register(user_data: schemas.UserCreate, db: Session = Depends(get_db)):
    # Check if duplicate email
    existing_user = db.query(models.User).filter(models.User.email == user_data.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # Custom Role constraints validation
    if user_data.role not in ["donor", "seeker", "hospital_admin", "super_admin"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid role selected"
        )
        
    hashed_password = auth.get_password_hash(user_data.password)
    
    new_user = models.User(
        name=user_data.name,
        email=user_data.email,
        password_hash=hashed_password,
        role=user_data.role,
        district_id=user_data.district_id
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    # If the registered user is a donor, automatically hook up a donor model
    if new_user.role == "donor":
        new_donor = models.Donor(
            user_id=new_user.id,
            blood_group="A+",  # Default blood group, user can change later during setup
            is_available=True
        )
        db.add(new_donor)
        db.commit()

    # Welcome notification
    welcome_notif = models.Notification(
        recipient_id=new_user.id,
        message=f"Welcome to Blood Reach BD, {new_user.name}! Your account has been successfully created."
    )
    db.add(welcome_notif)
    db.commit()
    
    return new_user

@router.post("/login", response_model=schemas.Token)
def login(login_data: schemas.UserLogin, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == login_data.email).first()
    if not user or not auth.verify_password(login_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=auth.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = auth.create_access_token(
        data={"sub": str(user.id), "role": user.role, "email": user.email},
        expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}
