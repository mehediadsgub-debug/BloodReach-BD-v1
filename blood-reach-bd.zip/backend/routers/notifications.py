from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional

from ..database import get_db
from .. import models, schemas, auth

router = APIRouter(prefix="/notifications", tags=["Notification Engine"])

@router.get("", response_model=List[schemas.NotificationOut])
def get_user_notifications(
    only_unread: bool = False,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(models.Notification).filter(models.Notification.recipient_id == current_user.id)
    if only_unread:
        query = query.filter(models.Notification.is_read == False)
        
    return query.order_by(models.Notification.created_at.desc()).all()

@router.patch("/read", response_model=List[schemas.NotificationOut])
def mark_notifications_as_read(
    notification_id: Optional[int] = None, # If None, mark all as read
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    if notification_id:
        notif = db.query(models.Notification).filter(
            models.Notification.id == notification_id,
            models.Notification.recipient_id == current_user.id
        ).first()
        if not notif:
            raise HTTPException(status_code=404, detail="Notification not found")
        notif.is_read = True
        db.commit()
        db.refresh(notif)
        return [notif]
    else:
        # Mark all as read
        notifs = db.query(models.Notification).filter(
            models.Notification.recipient_id == current_user.id,
            models.Notification.is_read == False
        ).all()
        for n in notifs:
            n.is_read = True
        db.commit()
        return notifs
