from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional

from ..database import get_db
from .. import models, schemas, auth

router = APIRouter(prefix="/requests", tags=["Blood Request System"])

@router.post("", response_model=schemas.BloodRequestOut)
def create_blood_request(
    req_data: schemas.BloodRequestCreate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    # Create request record
    new_request = models.BloodRequest(
        seeker_id=current_user.id,
        blood_group=req_data.blood_group,
        units=req_data.units,
        urgency=req_data.urgency,
        status="pending",
        district_id=req_data.district_id
    )
    db.add(new_request)
    db.flush() # Fetch generated ID
    
    # ─── REAL-TIME MATCHING & AUTOMATIC NOTIFICATION FEEDBACK ───
    # Match available donors of same blood group in the target district
    matched_donors = db.query(models.Donor).join(models.User).filter(
        models.Donor.blood_group == req_data.blood_group,
        models.User.district_id == req_data.district_id,
        models.Donor.is_available == True
    ).all()
    
    # Send a notification to each matched donor
    for d in matched_donors:
        notif = models.Notification(
            recipient_id=d.user_id,
            message=f"URGENT MATCH: A '{req_data.urgency}' blood request for {req_data.units} units of {req_data.blood_group} has been opened in your district. Please contact or support."
        )
        db.add(notif)
        
    db.commit()
    db.refresh(new_request)
    return new_request

@router.get("", response_model=List[schemas.BloodRequestOut])
def get_blood_requests(
    district_id: Optional[int] = None,
    blood_group: Optional[str] = None,
    status: Optional[str] = "pending",
    db: Session = Depends(get_db)
):
    query = db.query(models.BloodRequest)
    
    if district_id:
        query = query.filter(models.BloodRequest.district_id == district_id)
    if blood_group:
        query = query.filter(models.BloodRequest.blood_group == blood_group)
    if status:
        query = query.filter(models.BloodRequest.status == status)
        
    # ─── URGENCY-PRIORITIZATION SORTING ───
    # Critical first, then High, then Normal. We do this by mapping urgencies or filtering.
    # In SQLite/Postgres we can write order_by on a Case expression
    from sqlalchemy import case
    priority_order = case(
        (models.BloodRequest.urgency == "Critical", 1),
        (models.BloodRequest.urgency == "High", 2),
        (models.BloodRequest.urgency == "Normal", 3),
        else_=4
    )
    
    query = query.order_by(priority_order, models.BloodRequest.created_at.desc())
    return query.all()

@router.patch("/{id}", response_model=schemas.BloodRequestOut)
def update_request_status(
    id: int,
    status_update: schemas.BloodRequestUpdate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    req = db.query(models.BloodRequest).filter(models.BloodRequest.id == id).first()
    if not req:
        raise HTTPException(status_code=404, detail="Blood request not found")
        
    # Check if this is the seeker itself or an admin
    if req.seeker_id != current_user.id and current_user.role not in ["super_admin", "hospital_admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to close or update this blood request"
        )
        
    req.status = status_update.status
    
    # Notify seeker when request is fulfilled
    if status_update.status == "fulfilled":
        notif = models.Notification(
            recipient_id=req.seeker_id,
            message=f"Good news! Your blood request of {req.units} units of {req.blood_group} has been marked as fulfilled."
        )
        db.add(notif)
        
    db.commit()
    db.refresh(req)
    return req
