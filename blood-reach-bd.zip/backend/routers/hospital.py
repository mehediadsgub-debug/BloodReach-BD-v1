from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional

from ..database import get_db
from .. import models, schemas, auth

router = APIRouter(tags=["Hospital Inventory Module"])

@router.get("/hospitals", response_model=List[schemas.HospitalOut])
def get_hospitals(
    district_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    query = db.query(models.Hospital)
    if district_id:
        query = query.filter(models.Hospital.district_id == district_id)
    return query.all()

@router.get("/inventory", response_model=List[schemas.HospitalInventoryOut])
def get_hospital_inventory(
    hospital_id: int,
    db: Session = Depends(get_db)
):
    inv = db.query(models.HospitalInventory).filter(models.HospitalInventory.hospital_id == hospital_id).all()
    return inv

@router.post("/inventory", response_model=schemas.HospitalInventoryOut)
def add_or_update_inventory(
    inv_data: schemas.HospitalInventoryCreate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    # Verify current user holds active permissions
    if current_user.role not in ["hospital_admin", "super_admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Unauthorized: Only Hospital admins or Super Admins can update stock"
        )
        
    hospital = db.query(models.Hospital).filter(models.Hospital.id == inv_data.hospital_id).first()
    if not hospital:
        raise HTTPException(status_code=404, detail="Hospital not found")
        
    # Check if the user is authorized to manage this hospital
    if current_user.role == "hospital_admin" and hospital.admin_user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You are not authorized to manage stock for this specific hospital"
        )
        
    # Upsert logic
    inv_item = db.query(models.HospitalInventory).filter(
        models.HospitalInventory.hospital_id == inv_data.hospital_id,
        models.HospitalInventory.blood_group == inv_data.blood_group
    ).first()
    
    if inv_item:
        inv_item.units_available = inv_data.units_available
    else:
        inv_item = models.HospitalInventory(
            hospital_id=inv_data.hospital_id,
            blood_group=inv_data.blood_group,
            units_available=inv_data.units_available
        )
        db.add(inv_item)
        
    db.flush()
    
    # ─── LOW-STOCK ALERT TRIGGER LOGIC ───
    # If units drop below or equal to 3, trigger a low-stock admin alert
    if inv_item.units_available <= 3:
        alert_notif = models.Notification(
            recipient_id=current_user.id,
            message=f"LOW STOCK WARNING: Stock for blood group '{inv_item.blood_group}' in your hospital has fallen to {inv_item.units_available} units. Please replenish soon."
        )
        db.add(alert_notif)
        
    db.commit()
    db.refresh(inv_item)
    return inv_item

@router.put("/inventory/{id}", response_model=schemas.HospitalInventoryOut)
def update_inventory_units(
    id: int,
    units_update: schemas.HospitalInventoryUpdate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    inv_item = db.query(models.HospitalInventory).filter(models.HospitalInventory.id == id).first()
    if not inv_item:
        raise HTTPException(status_code=404, detail="Inventory item not found")
        
    hospital = db.query(models.Hospital).filter(models.Hospital.id == inv_item.hospital_id).first()
    
    if current_user.role == "hospital_admin" and hospital.admin_user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You are not authorized to manage this inventory"
        )
        
    inv_item.units_available = units_update.units_available
    
    # Low-stock alert validation
    if inv_item.units_available <= 3:
        alert_notif = models.Notification(
            recipient_id=hospital.admin_user_id if hospital.admin_user_id else current_user.id,
            message=f"LOW STOCK WARNING: Stock for blood group '{inv_item.blood_group}' in '{hospital.name}' has fallen to {inv_item.units_available} units."
        )
        db.add(alert_notif)
        
    db.commit()
    db.refresh(inv_item)
    return inv_item
