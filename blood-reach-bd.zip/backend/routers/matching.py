from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from ..database import get_db
from .. import models, schemas

router = APIRouter(prefix="/match", tags=["Location Based Donor Matching"])

@router.get("", response_model=List[schemas.DonorMatchOut])
def match_donors(
    blood_group: str,
    district_id: int,
    db: Session = Depends(get_db)
):
    # 1. Fetch search reference district & division
    target_district = db.query(models.District).filter(models.District.id == district_id).first()
    if not target_district:
        raise HTTPException(status_code=400, detail="Target district id not found")
        
    target_division_id = target_district.division_id

    # 2. Grab all available active donors with matching blood group
    raw_donors = db.query(models.Donor).join(models.User).filter(
        models.Donor.blood_group == blood_group,
        models.Donor.is_available == True
    ).all()

    results = []
    for d in raw_donors:
        donor_user = d.user
        donor_district_id = donor_user.district_id
        
        # Determine proximity rank
        if donor_district_id == district_id:
            rank = 1  # Same District
        else:
            # Check division
            donor_dist_obj = db.query(models.District).filter(models.District.id == donor_district_id).first()
            if donor_dist_obj and donor_dist_obj.division_id == target_division_id:
                rank = 2  # Same Division, Different District
            else:
                rank = 3  # Different Division (Rest of Bangladesh)

        # Get names for presentation
        dist_name = "Unknown"
        div_name = "Unknown"
        dist_obj = db.query(models.District).filter(models.District.id == donor_district_id).first()
        if dist_obj:
            dist_name = dist_obj.name
            div_name = dist_obj.division.name

        results.append(
            schemas.DonorMatchOut(
                donor_id=d.id,
                name=donor_user.name,
                email=donor_user.email,
                blood_group=d.blood_group,
                district=dist_name,
                division=div_name,
                is_available=d.is_available,
                proximity_rank=rank
            )
        )

    # Sort results by proximity rank (1 is best, followed by 2, then 3)
    results.sort(key=lambda x: x.proximity_rank)
    return results
