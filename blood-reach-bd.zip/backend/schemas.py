from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import date, datetime

# Division and District Schemas
class DivisionBase(BaseModel):
    name: str

class DivisionOut(DivisionBase):
    id: int
    class Config:
        from_attributes = True

class DistrictBase(BaseModel):
    name: str
    division_id: int

class DistrictOut(DistrictBase):
    id: int
    class Config:
        from_attributes = True

# Token Schemas
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    user_id: Optional[int] = None
    role: Optional[str] = None

# User Schemas
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: str  # "donor", "seeker", "hospital_admin", "super_admin"
    district_id: Optional[int] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: str
    district_id: Optional[int] = None
    class Config:
        from_attributes = True

# Donor Schemas
class DonorCreate(BaseModel):
    blood_group: str
    is_available: bool = True
    last_donated: Optional[date] = None

class DonorUpdate(BaseModel):
    blood_group: Optional[str] = None
    is_available: Optional[bool] = None
    last_donated: Optional[date] = None

class DonorOut(BaseModel):
    id: int
    user_id: int
    blood_group: str
    is_available: bool
    last_donated: Optional[date] = None
    user: Optional[UserOut] = None
    class Config:
        from_attributes = True

# Blood Request Schemas
class BloodRequestCreate(BaseModel):
    blood_group: str
    units: int = 1
    urgency: str  # "Critical", "High", "Normal"
    district_id: int

class BloodRequestUpdate(BaseModel):
    status: str  # "pending", "fulfilled"

class BloodRequestOut(BaseModel):
    id: int
    seeker_id: int
    blood_group: str
    units: int
    urgency: str
    status: str
    district_id: int
    created_at: datetime
    seeker: UserOut
    district: DistrictOut
    class Config:
        from_attributes = True

# Hospital Inventory & Hospital Schemas
class HospitalInventoryBase(BaseModel):
    blood_group: str
    units_available: int

class HospitalInventoryCreate(HospitalInventoryBase):
    hospital_id: int

class HospitalInventoryUpdate(BaseModel):
    units_available: int

class HospitalInventoryOut(HospitalInventoryBase):
    id: int
    hospital_id: int
    class Config:
        from_attributes = True

class HospitalBase(BaseModel):
    name: str
    district_id: int

class HospitalCreate(HospitalBase):
    admin_user_id: Optional[int] = None

class HospitalOut(HospitalBase):
    id: int
    admin_user_id: Optional[int] = None
    inventory: List[HospitalInventoryOut] = []
    class Config:
        from_attributes = True

# Notification Schemas
class NotificationOut(BaseModel):
    id: int
    recipient_id: int
    message: str
    is_read: bool
    created_at: datetime
    class Config:
        from_attributes = True

# Matching results
class DonorMatchOut(BaseModel):
    donor_id: int
    name: str
    email: str
    blood_group: str
    district: str
    division: str
    is_available: bool
    proximity_rank: int  # 1 = same district, 2 = same division, 3 = other
