# Blood Reach BD – FastAPI & PostgreSQL Production Backend

This directory contains the production-grade, highly-scalable, modular Python backend for **Blood Reach BD – Real-Time Blood Availability & Donor Matching Platform**.

---

## 📂 Project Directory Structure

```text
backend/
├── main.py              # FastAPI application entrypoint with CORS, startup triggers, and global handlers
├── database.py          # SQLAlchemy engine, session maker, and DB connections manager
├── models.py            # Complete PostgreSQL tables representation using SQLAlchemy declarative mapping
├── schemas.py           # Pydantic schemas validating user authentication, donor updates, and matching
├── auth.py              # CryptContext security configuration, password hashing, and OAuth2 security dependencies
├── seed.py              # Comprehensive seed script with Bangladesh divisions/districts and test accounts
├── routers/
│   ├── auth.py          # Register, Login routing logic and automated token generation
│   ├── donor.py         # Profile editing and availability toggle routers
│   ├── requests.py      # Urgency request generation and automatic notification dispatches
│   ├── matching.py      # Real-time search matching with geographic proximity sorting
│   ├── hospital.py      # Hospital profiles and clinical inventory tracking with notifications trigger
│   └── notifications.py # Live notification alerts pull and read-status modifiers
└── requirements.txt     # Python production-grade dependencies definition
```

---

## 🛠️ Step-by-Step Setup Instructions

### 1. Database Setup (PostgreSQL)

1. Make sure you have a working PostgreSQL server active locally or on a cloud host.
2. Log into your PostgreSQL instance and create a brand-new database:
   ```sql
   CREATE DATABASE blood_reach_bd;
   ```
3. Set up the `DATABASE_URL` environment variable pointing to your new database:
   ```bash
   # On macOS/Linux:
   export DATABASE_URL="postgresql://postgres_username:your_password@localhost:5432/blood_reach_bd"

   # On Windows (cmd):
   set DATABASE_URL=postgresql://postgres_username:your_password@localhost:5432/blood_reach_bd
   ```

---

### 2. Configure Local Virtual Environment & Install Dependencies

1. Launch your command-line shell inside the `backend` folder:
   ```bash
   cd backend
   ```
2. Setup and activate a Python virtual environment:
   ```bash
   # On macOS/Linux:
   python3 -m venv venv
   source venv/bin/activate

   # On Windows:
   python -m venv venv
   venv\Scripts\activate
   ```
3. Install dependencies from the requirements file:
   ```bash
   pip install -r requirements.txt
   ```

---

### 3. Seed Database & Run FastAPI Server

1. Run the database seed script to auto-generate PostgreSQL tables and pre-populate all Bangladeshi districts structured by division:
   ```bash
   python -m seed
   ```
   *Expected Output:*
   ```text
   Seeding divisions and districts of Bangladesh...
   Divisions and districts seeded successfully!
   Seeding demo users...
   Demo users, hospitals and donor details seeded successfully!
   ```

2. Boot the live development server with hot-reload support:
   ```bash
   uvicorn main:app --reload --port 8000
   ```
3. Open your browser and navigate to `http://127.0.5.1:8000/docs` to play around with the fully-documented **Swagger UI API**.

---

## 👥 Seeded Demo Login presets

Use the following profiles to test role-actions immediately on startup:
* **Super Admin**: `admin@bloodreach.bd` (password: `admin123`)
* **Hospital Admin (Dhaka Medical)**: `dmc@bloodreach.bd` (password: `hospital123`)
* **Active Blood Donor**: `rahim@dummy.com` (password: `donor123`)
* **Blood seeker**: `tasnim@dummy.com` (password: `seeker123`)
