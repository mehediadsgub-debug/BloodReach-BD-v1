from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List, Dict, Any

from .database import Base, engine, get_db
from . import models, schemas
from .routers import auth, donor, requests, matching, hospital, notifications
from .seed import seed_database

# Setup database tables
Base.metadata.create_all(bind=engine)

# Auto-seed on server import/start
try:
    seed_database()
except Exception as e:
    print(f"Skipping seeding, already configured or error: {e}")

app = FastAPI(
    title="Blood Reach BD – API",
    description="Scalable blood availability, request matching, and notifications engine for Bangladesh",
    version="1.0.0"
)

# CORS Config
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Router Modules
app.include_router(auth.router)
app.include_router(donor.router)
app.include_router(requests.router)
app.include_router(matching.router)
app.include_router(hospital.router)
app.include_router(notifications.router)

# Extra details: Divisions and Districts endpoints
@app.get("/divisions", response_model=List[schemas.DivisionOut], tags=["Location Helper"])
def get_divisions(db: Session = Depends(get_db)):
    return db.query(models.Division).all()

@app.get("/districts", response_model=List[schemas.DistrictOut], tags=["Location Helper"])
def get_districts(db: Session = Depends(get_db)):
    return db.query(models.District).all()

# Direct Admin Analytics endpoint
@app.get("/admin/analytics", tags=["System Analytics"])
def get_system_analytics(
    db: Session = Depends(get_db)
):
    total_users = db.query(models.User).count()
    total_donors = db.query(models.Donor).count()
    active_donors = db.query(models.Donor).filter(models.Donor.is_available == True).count()
    total_requests = db.query(models.BloodRequest).count()
    pending_requests = db.query(models.BloodRequest).filter(models.BloodRequest.status == "pending").count()
    fulfilled_requests = db.query(models.BloodRequest).filter(models.BloodRequest.status == "fulfilled").count()
    total_hospitals = db.query(models.Hospital).count()

    return {
        "total_users": total_users,
        "total_donors": total_donors,
        "active_donors": active_donors,
        "total_requests": total_requests,
        "pending_requests": pending_requests,
        "fulfilled_requests": fulfilled_requests,
        "total_hospitals": total_hospitals
    }

@app.get("/", tags=["Main"])
def read_root():
    return {
        "status": "online",
        "service": "Blood Reach BD API Service",
        "version": "1.0.0",
        "docs": "/docs"
    }
