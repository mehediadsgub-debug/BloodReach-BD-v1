from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Date, DateTime, Text, func
from sqlalchemy.orm import relationship
from .database import Base

class Division(Base):
    __tablename__ = "divisions"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False, unique=True)

    # Relationships
    districts = relationship("District", back_populates="division", cascade="all, delete-orphan")


class District(Base):
    __tablename__ = "districts"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False, unique=True)
    division_id = Column(Integer, ForeignKey("divisions.id", ondelete="CASCADE"), nullable=False)

    # Relationships
    division = relationship("Division", back_populates="districts")
    users = relationship("User", back_populates="district")
    blood_requests = relationship("BloodRequest", back_populates="district")
    hospitals = relationship("Hospital", back_populates="district")


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(100), nullable=False, unique=True, index=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, default="seeker")  # "donor", "seeker", "hospital_admin", "super_admin"
    district_id = Column(Integer, ForeignKey("districts.id"), nullable=True)

    # Relationships
    district = relationship("District", back_populates="users")
    donor_profile = relationship("Donor", back_populates="user", uselist=False, cascade="all, delete-orphan")
    blood_requests = relationship("BloodRequest", back_populates="seeker")
    managed_hospitals = relationship("Hospital", back_populates="admin_user")
    notifications = relationship("Notification", back_populates="recipient", cascade="all, delete-orphan")


class Donor(Base):
    __tablename__ = "donors"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True)
    blood_group = Column(String(5), nullable=False)  # A+, A-, B+, B-, O+, O-, AB+, AB-
    is_available = Column(Boolean, nullable=False, default=True)
    last_donated = Column(Date, nullable=True)

    # Relationships
    user = relationship("User", back_populates="donor_profile")


class BloodRequest(Base):
    __tablename__ = "blood_requests"

    id = Column(Integer, primary_key=True, index=True)
    seeker_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    blood_group = Column(String(5), nullable=False)
    units = Column(Integer, nullable=False, default=1)
    urgency = Column(String(20), nullable=False, default="Normal")  # "Critical", "High", "Normal"
    status = Column(String(20), nullable=False, default="pending")  # "pending", "fulfilled"
    district_id = Column(Integer, ForeignKey("districts.id"), nullable=False)
    created_at = Column(DateTime, server_default=func.now())

    # Relationships
    seeker = relationship("User", back_populates="blood_requests")
    district = relationship("District", back_populates="blood_requests")


class Hospital(Base):
    __tablename__ = "hospitals"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    district_id = Column(Integer, ForeignKey("districts.id"), nullable=False)
    admin_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)

    # Relationships
    district = relationship("District", back_populates="hospitals")
    admin_user = relationship("User", back_populates="managed_hospitals")
    inventory = relationship("HospitalInventory", back_populates="hospital", cascade="all, delete-orphan")


class HospitalInventory(Base):
    __tablename__ = "hospital_inventory"

    id = Column(Integer, primary_key=True, index=True)
    hospital_id = Column(Integer, ForeignKey("hospitals.id", ondelete="CASCADE"), nullable=False)
    blood_group = Column(String(5), nullable=False)
    units_available = Column(Integer, nullable=False, default=0)

    # Relationships
    hospital = relationship("Hospital", back_populates="inventory")


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    recipient_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    message = Column(Text, nullable=False)
    is_read = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime, server_default=func.now())

    # Relationships
    recipient = relationship("User", back_populates="notifications")
