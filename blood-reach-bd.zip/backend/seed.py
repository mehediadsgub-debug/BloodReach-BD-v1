from sqlalchemy.orm import Session
from .database import SessionLocal, Base, engine
from . import models, auth

def seed_database():
    # Make sure tables exist
    Base.metadata.create_all(bind=engine)
    
    db = SessionLocal()
    try:
        # Check if already seeded
        if db.query(models.Division).first() is not None:
            print("Database already seeded.")
            return

        print("Seeding divisions and districts of Bangladesh...")
        
        # Division Data
        bd_data = {
            "Dhaka": ["Dhaka", "Faridpur", "Gazipur", "Gopalganj", "Kishoreganj", "Madaripur", "Manikganj", "Munshiganj", "Narayanganj", "Narsingdi", "Rajbari", "Shariatpur", "Tangail"],
            "Chittagong": ["Bandarban", "Brahmanbaria", "Chandpur", "Chittagong", "Comilla", "Cox's Bazar", "Feni", "Khagrachhari", "Lakshmipur", "Noakhali", "Rangamati"],
            "Rajshahi": ["Bogra", "Joypurhat", "Naogaon", "Natore", "Chapainawabganj", "Pabna", "Rajshahi", "Sirajganj"],
            "Khulna": ["Bagerhat", "Chuadanga", "Jessore", "Jhenaidah", "Khulna", "Kushtia", "Magura", "Meherpur", "Narail", "Satkhira"],
            "Barisal": ["Barguna", "Barisal", "Bhola", "Jhalokati", "Patuakhali", "Pirojpur"],
            "Sylhet": ["Habiganj", "Moulvibazar", "Sunamganj", "Sylhet"],
            "Rangpur": ["Dinajpur", "Gaibandha", "Kurigram", "Lalmonirhat", "Nilphamari", "Panchagarh", "Rangpur", "Thakurgaon"],
            "Mymensingh": ["Jamalpur", "Mymensingh", "Netrokona", "Sherpur"]
        }

        district_id_map = {}

        for div_name, dist_list in bd_data.items():
            division = models.Division(name=div_name)
            db.add(division)
            db.flush()  # Gets the ID of the division
            
            for dist_name in dist_list:
                district = models.District(name=dist_name, division_id=division.id)
                db.add(district)
                db.flush()
                district_id_map[dist_name] = district.id

        db.commit()
        print("Divisions and districts seeded successfully!")

        print("Seeding demo users...")
        
        # Seed Super Admin
        dhaka_id = district_id_map["Dhaka"]
        super_admin = models.User(
            name="Super Admin",
            email="admin@bloodreach.bd",
            password_hash=auth.get_password_hash("admin123"),
            role="super_admin",
            district_id=dhaka_id
        )
        db.add(super_admin)
        
        # Seed Hospital Admin & Hospital
        h_admin = models.User(
            name="Dhaka Medical Admin",
            email="dmc@bloodreach.bd",
            password_hash=auth.get_password_hash("hospital123"),
            role="hospital_admin",
            district_id=dhaka_id
        )
        db.add(h_admin)
        db.flush()

        hospital = models.Hospital(
            name="Dhaka Medical College Hospital",
            district_id=dhaka_id,
            admin_user_id=h_admin.id
        )
        db.add(hospital)
        db.flush()

        # Seed Hospital Inventory
        blood_groups = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"]
        for bg in blood_groups:
            inv = models.HospitalInventory(
                hospital_id=hospital.id,
                blood_group=bg,
                units_available=10 if bg in ["O+", "A+", "B+"] else 2
            )
            db.add(inv)

        # Seed Demo Donors
        donors_data = [
            {"name": "Rahim Uddin", "email": "rahim@dummy.com", "bg": "A+", "district": "Dhaka"},
            {"name": "Karim Lal", "email": "karim@dummy.com", "bg": "O+", "district": "Dhaka"},
            {"name": "Sajid Hasan", "email": "sajid@dummy.com", "bg": "B+", "district": "Chittagong"},
            {"name": "Nadia Begum", "email": "nadia@dummy.com", "bg": "AB+", "district": "Sylhet"}
        ]

        for donor_item in donors_data:
            dist_id = district_id_map[donor_item["district"]]
            u = models.User(
                name=donor_item["name"],
                email=donor_item["email"],
                password_hash=auth.get_password_hash("donor123"),
                role="donor",
                district_id=dist_id
            )
            db.add(u)
            db.flush()

            d = models.Donor(
                user_id=u.id,
                blood_group=donor_item["bg"],
                is_available=True
            )
            db.add(d)

        # Seed Demo Seeker
        seeker = models.User(
            name="Tasnim Alam",
            email="tasnim@dummy.com",
            password_hash=auth.get_password_hash("seeker123"),
            role="seeker",
            district_id=dhaka_id
        )
        db.add(seeker)
        db.flush()

        # Seed Blood Request
        req = models.BloodRequest(
            seeker_id=seeker.id,
            blood_group="A+",
            units=2,
            urgency="High",
            status="pending",
            district_id=dhaka_id
        )
        db.add(req)

        db.commit()
        print("Demo users, hospitals and donor details seeded successfully!")
        
    except Exception as e:
        db.rollback()
        print(f"Error during seeding: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
